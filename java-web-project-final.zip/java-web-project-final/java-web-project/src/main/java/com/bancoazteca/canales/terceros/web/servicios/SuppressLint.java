package com.bancoazteca.canales.terceros.web.servicios;

import java.lang.annotation.Documented;

@Documented
public @interface SuppressLint {

	String value();

}
