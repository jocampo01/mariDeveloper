package com.bancoazteca.canales.terceros.web.utilerias;

public enum CodigosResponseWS {

		PROCESO_TERMINDO_CORRECTAMENTE(2L,"Proceso terminado correctamente"),
		ERROR_CONEXION(600L,"Error de conexion"),
		GUARDAR_SOLICITUD_EN_BD(3l,"Error al guardar solicitud en BD"),
		ERROR_INESPERADO(5L,"Error inesperado"),
		ERROR_PROXY(7L, "Error en proxy");
		
		private CodigosResponseWS(Long idCodigo, String descripcion) {
			this.idCodigo = idCodigo;
			this.descripcion = descripcion;
		}

		private  Long idCodigo;
		
		private  String descripcion;
		

		public Long getIdCodigo() {
			return idCodigo;
		}

		public void setIdCodigo(Long idCodigo) {
			this.idCodigo = idCodigo;
		}

		public String getDescripcion() {
			return descripcion;
		}

		public void setDescripcion(String descripcion) {
			this.descripcion = descripcion;
		}
		
	}
