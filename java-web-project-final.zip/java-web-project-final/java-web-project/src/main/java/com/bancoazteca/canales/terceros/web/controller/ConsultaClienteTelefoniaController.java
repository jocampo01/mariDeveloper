package com.bancoazteca.canales.terceros.web.controller;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bancoazteca.canales.terceros.web.constantes.StatusPeticion;
import com.bancoazteca.canales.terceros.web.servicios.WSConsultaClienteTelefonia;
import com.bancoazteca.canales.terceros.web.utilerias.CodigosResponseWS;
import com.bancoazteca.canales.terceros.web.utilerias.ContenedorResponse;
import com.bancoazteca.canales.terceros.web.utilerias.UtileriasHelper;

@RestController
@RequestMapping(value = "/consultaOrquestadorTelefonia")
public class ConsultaClienteTelefoniaController {

	Logger logger = Logger.getLogger(ConsultaClienteTelefoniaController.class);

	private UtileriasHelper utileriasHelper;

	private WSConsultaClienteTelefonia WSConsultaClienteTelefonia;

	String datos = "";

	@RequestMapping(value = "/buscarClientes", method = { RequestMethod.GET }, produces = {
			MediaType.APPLICATION_JSON })
	public @ResponseBody ContenedorResponse<?> buscarDepartamentos(@RequestParam(value = "idproducto") int idproducto,
			@RequestParam(value = "pais") int pais, @RequestParam(value = "canal") int canal,
			@RequestParam(value = "sucursal") int sucursal, @RequestParam(value = "folio") int folio,
			HttpServletRequest request) {

		logger.debug("[INICIA -- CONSULTAR DATOS CLIENTES ORQUESTADOR TELEFONIA ]");
		ContenedorResponse<ArrayList<HashMap<String, Object>>> contenedor = new ContenedorResponse<ArrayList<HashMap<String, Object>>>();

		try {
			datos = WSConsultaClienteTelefonia.transaccionConsultaCUTelefonia(idproducto, pais, canal, sucursal, folio);

			if (datos != null) {
				contenedor = utileriasHelper.llenarContenedorResponse(CodigosResponseWS.PROCESO_TERMINDO_CORRECTAMENTE,
						false, "Exito", datos);
			} else {
				contenedor.setCodigo(404L);
				contenedor.setData(null);
				contenedor.setDescripcion("No se encontraron datos del CU");
				contenedor.setError(false);
				contenedor.setStatus(StatusPeticion.ERROR);
			}
		} catch (Exception e) {
			contenedor = utileriasHelper.llenarContenedorResponse(CodigosResponseWS.ERROR_INESPERADO, true,
					e.getMessage());
		}
		logger.debug("[FINALIZA -- CONSULTAR DATOS RECOMPRA]");
		return contenedor;
	}

}
