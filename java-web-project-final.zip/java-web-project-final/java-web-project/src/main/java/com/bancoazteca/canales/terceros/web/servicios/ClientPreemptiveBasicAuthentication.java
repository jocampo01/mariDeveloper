package com.bancoazteca.canales.terceros.web.servicios;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.OkHttpClient.Builder;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ClientPreemptiveBasicAuthentication {

	public static void main(String args[]) throws Exception {
		String accessToken = "";

		OkHttpClient.Builder builder = new OkHttpClient.Builder();
		OkHttpClient client = new OkHttpClient();
		Builder cliente = new OkHttpClient.Builder();
		try {

			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				@Override
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				@Override
				public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
					// TODO Auto-generated method stub

				}

				@Override
				public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
					// TODO Auto-generated method stub

				}
			} };

			// Create all-trusting host name verifier
			HostnameVerifier allHostsValid = new HostnameVerifier() {
				@Override
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			};

			try {
				// Install the all-trusting trust manager
				SSLContext sslContext = SSLContext.getInstance("SSL");
				sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
				SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
				// Install the all-trusting host verifier
				builder.hostnameVerifier(allHostsValid);
				builder.sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0]);
				/*
				 * builder.hostnameVerifier(new HostnameVerifier() {
				 * 
				 * @SuppressLint("BadHostnameVerifier")
				 * 
				 * @Override public boolean verify(String hostname, SSLSession session) { return
				 * true; } });
				 */
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
		RequestBody body = RequestBody.create(mediaType, "grant_type=client_credentials");
		Request request = new Request.Builder().url("https://dev-api.bancoazteca.com.mx:8080/oauth2/v1/token")
				.post(body).addHeader("Content-Type", "application/x-www-form-urlencoded")
				.addHeader("grant_type", "client_credentials")
				.addHeader("Authorization",
						"Basic dFVKZUF5YzZpVWZsR0RSbU85Q2xSVDVCQ2NYUmMySUk6aGphOG1yYm5LV3dsdWdiVg==")
				.addHeader("User-Agent", "PostmanRuntime/7.17.1").addHeader("Accept", "*/*")
				.addHeader("Cache-Control", "no-cache")
				.addHeader("Postman-Token", "f9c62764-2a4e-48f3-9cec-d213284da30b,0c73d764-11d7-4f38-b189-a6d57609a911")
				.addHeader("Host", "dev-api.bancoazteca.com.mx:8080").addHeader("Accept-Encoding", "gzip, deflate")
				.addHeader("Content-Length", "29").addHeader("Connection", "keep-alive")
				.addHeader("cache-control", "no-cache").build();

		 OkHttpClient  OkHttpClient=builder.build();
		 Response response = OkHttpClient.newCall(request).execute();
		 System.out.println(response);
	}

}