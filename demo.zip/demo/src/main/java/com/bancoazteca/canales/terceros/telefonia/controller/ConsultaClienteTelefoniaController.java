package com.bancoazteca.canales.terceros.telefonia.controller;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.bancoazteca.canales.terceros.telefonia.utilerias.*;
import com.bancoazteca.canales.terceros.telefonia.constantes.StatusPeticion;
import com.bancoazteca.canales.terceros.telefonia.servicios.*;


@RestController
@RequestMapping("/ConsultaOrquestadorTelefonia")
public class ConsultaClienteTelefoniaController {

Logger logger = Logger.getLogger(ConsultaClienteTelefoniaController.class);
	
	private UtileriasHelper utileriasHelper;
	
	private WSConsultaClienteTelefonia WSConsultaClienteTelefonia;

    String datos="";
	@RequestMapping(value="/buscadorClientesTelefonia", method={RequestMethod.GET}, produces={"application/json; charset=UTF-8"})
	public @ResponseBody ContenedorResponse<?> buscadorClientes(
                                                                @RequestParam(value="pais", required=false) Integer pais,
                                                                @RequestParam(value="canal", required=false) Integer canal,
                                                                @RequestParam(value="sucursal", required=false) Integer sucursal,
                                                                @RequestParam(value="folio", required=false) Integer folio,
                                                                HttpServletRequest request,
                                                                HttpServletResponse response) {
		
	    logger.debug("[INICIA -- CONSULTAR DATOS CLIENTES ORQUESTADOR TELEFONIA ]"); 
        ContenedorResponse<ArrayList<HashMap<String, Object>>> contenedor = new ContenedorResponse<ArrayList<HashMap<String, Object>>>();

        try {
            if(pais != null && pais != 0 && canal != null && canal != 0 && sucursal != null && sucursal != 0 && folio != null && folio != 0) {
            	datos = WSConsultaClienteTelefonia.transaccionConsultaCUTelefonia(pais, canal, sucursal, folio);
                    }else {
                    	 logger.debug("No se cuenta con algun campo del codigo del cliente unico para la consulta X_X");
                        contenedor.setCodigo(404L);
                        contenedor.setData(null);
                        contenedor.setDescripcion("No se pudo conectar al servicio");
                        contenedor.setError(true);
                        contenedor.setStatus(StatusPeticion.ERROR);
                        logger.debug("[FINALIZA -- CONSULTAR DATOS RECOMPRA]");
                        return contenedor;
                    }
  
            if(datos != null) {
                contenedor = utileriasHelper.llenarContenedorResponse(CodigosResponseWS.PROCESO_TERMINDO_CORRECTAMENTE, false, "Exito", datos);
            }else {
                contenedor.setCodigo(404L);
                contenedor.setData(null);
                contenedor.setDescripcion("No se encontraron datos del CU");
                contenedor.setError(false);
                contenedor.setStatus(StatusPeticion.ERROR);
            }
	    }catch(Exception e) {
	        contenedor = utileriasHelper.llenarContenedorResponse(CodigosResponseWS.ERROR_INESPERADO, true, e.getMessage());
	    }
        logger.debug("[FINALIZA -- CONSULTAR DATOS RECOMPRA]");
	    return contenedor;
	}
	
}
