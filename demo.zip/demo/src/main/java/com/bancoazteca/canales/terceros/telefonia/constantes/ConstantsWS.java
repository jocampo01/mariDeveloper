package com.bancoazteca.canales.terceros.telefonia.constantes;

public class ConstantsWS {

	/*
	 * Datos de la versi�n del aplicativo
	 * 
	 * @Versi�n
	 * 
	 * @Carpeta Virtual *
	 */

	public static final String LLAVE_CIFRADO = "U2FsdGVkX1/7QtF2CTaJm2b1JwhUwPrQ6Yvk4+iiwSk="; // MasterKey
	public static final String US_TRANSACCION_ALNOVA = "BPPDINDI";
	public static final String TK_TRANSACCION_ALNOVA = "Rhn08kjQ4oHI1uOMG1ymOg";
	public static final String LLAVE_CIFRADO_ALNOVA = "B2A0A0R2N1Q8C0U7O2I0A1T6ZETCETCU";
	public static final String IV_CIFRADO_ALNOVA = "02A681F1198B8760E65681C165885D34";
	public static final String US_TRANSACCION_ALNOVA_PROMOCION = "BINTSDBD";

	public static final String JSON_APPLICATION = "Accept=application/json";
	public static final String JSON = "application/json";
	public static final String CHARSET_UTF8 = ";charset=utf-8";
	public static final String TEXT_XML = "text/xml";
	public static final String ISO_88591 = "ISO-8859-1";
	public static final String UTF_8 = "UTF-8";
	public static final String WWW_FORM_URLENCODED = "application/x-www-form-urlencoded";
	public static final String CADENA_SQL_SERVER = "jdbc:sqlserver://";
	public static final String PUERTO_SQL_SERVER = ":1433;";
	public static final int TIME_OUT = 180;
	public static final String BD_NAME_FLUJO_WINDOWS = "ADN";
	public static final String BD_NAME_FLUJO_WINDOWS_TOTALPLAY = "ADN2";
	public static final int TIME_OUT_FLUJO_WINDOWS_PARAMETRO = 300;
	public static final int TIME_OUT_FLUJO_WINDOWS = 310000;
	public static final String BANDERA_TRUE = "true";
	public static final String BANDERA_FALSE = "false";
	public static final int OFERTA_DIAS_CDP = 30;
	public static final int OFERTA_DIAS_NEGATIVA_CDP = -30;
	public static final String IP_DESARROLLO = "10.54.28.114";
	
	public static final int CONNECT_TIME_OUT_FLUJO_CU = 90000;
	public static final int READ_TIME_OUT_FLUJO_CU = 90000;
	public static final int BURO_EXTERNO_TIME_OUT = 180000;
	public static final int SCORING_5MATRICES_TIME_OUT = 60000;
	public static final int ORQUESTADOR_BURO_TIME_OUT = 120000;

	public static final int SERVICE_GET_CONECTION_TIMEOUT = 200000;

	public static final long SP_TIENDA_ID_ESTADO = 30000;
	
	/*
	 * Datos requeridos para Lista Negra
	 */

	public static final String BLACKLIST_SUCURSAL = "0172";
	public static final String BLACKLIST_NOMBRE_SUCURSAL = "CREDITO CENTRALIZADO";
	public static final String BLACKLIST_CANAL = "01";
	public static final String BLACKLIST_PAIS = "0127"; // MEXICO
	public static final String BLACKLIST_PAIS_PERU = "0140"; // MEXICO
	public static final String BLACKLIST_TERMINAL = "WE50";
	public static final String BLACKLIST_USER = "B242616";
	public static final String BLACKLIST_PRODUCTO = "79";
	public static final String BLACKLIST_SUBPRODUCTO = "0000";
	public static final String BLACKLIST_ENCONTRADO = "PEA0093";

	/*
	 * Nombre de archivos XSD para validaciones
	 */

	public static final String XSD_DATOS_BASICO_CLIENTE = "DatosBasicosCliente.xsd";
	public static final String XSD_DATOS_DEL_PROSPECTO = "DatosDelProspecto.xsd";
	public static final String XSD_DATOS_DEL_AVAL = "DatosDelAval.xsd";
	public static final String XSD_DATOS_DEL_HOGAR = "DatosDelHogar.xsd";
	public static final String XSD_REFERENCIAS_CLIENTE = "ReferenciasCliente.xsd";
	public static final String XSD_DATOS_EMPLEO = "DatosEmpleo.xsd";
	public static final String XSD_INGRESOS_EGRESOS = "IngresosEgresos.xsd";

	/*
	 * CONTROLLER REQUEST
	 */
	public static final String CTR_OBTENER_GENERAR_PEDIDO_DIGITAL = "/ctrGenerarPedido";
	public static final String CTR_GENERAR_PEDIDO_RECOMPRA_PRESTAMOS = "/ctrGenerarPedidoPrestamoRecompra";
	public static final String CTR_SOLICITUD = "/ctrSolicitud";
	public static final String CTR_SOLP_DATOS_EMPLEO = "/ctrDatosEmpleo";
	public static final String CTR_SOLP_INGRESOS_EGRESOS = "/ctrIngresosEgresos";
	public static final String CTR_SOLP_CONSULTA_HOMO = "/ctrConsultaHomonimos";
	public static final String CTR_CONSULTA_HOMONIMOS_INE = "/ctrHomonimosINE";
	public static final String CTR_SOLP_SIMULACION = "/DatosSimulacion";
	public static final String CTR_SOLP_AVAL = "/DatosAval";
	public static final String CTR_SOLP_EXPEDIENTES = "/Expedientes";
	public static final String CTR_GENERAR_SOLICITUD = "/ctrGenerarSolicitudPrestamo";
	public static final String CTR_SOLP_AGENDAR_CITA = "/ctrAgendarCita";
	public static final String CTR_SOLP_AGENDAR_CITA_BAZ_DIGITAL = "/ctrAgendarCitaBazDigital";
	public static final String CTR_FOTO_HUELLA = "/huellaFoto";
	public static final String CTR_CONSULTA_ASESOR = "/ctrConsultaAsesor";
	public static final String CTR_SOLP_AGENDAR_LLAMADA = "/ctrAgendarLlamada";
	public static final String CTR_SOLP_LIBERACION = "/ctrLiberacion";

	public static final String CTR_ACTUALIZAR_DIGITALIZACION = "/ctrActualizarDigitalizacion";
	public static final String CTR_GENERAR_CONTRATOS_DIGITALZIADOS = "/ctrGenerarContratosDigitalizados";

	public static final String CTR_OBTENER_SOLICITUDES = "/ctrObtenerSolicitudes";

	public static final String CTR_OBTENER_CLIENTE_UNICO = "/ctrObtenerClienteUnico";

	public static final String CTR_SERVICIOS_CLIENTE_UNICO = "/serviciosClienteUnico";

	public static final String CTR_SERVICIOS_CONSULTA_CENTRAL = "/serviciosConsultaCentral";

	public static final String CTR_CODIGO_REENVIAR = "/Codigo/reEnviar";
	public static final String CTR_CELULAR_UNICO = "/celularUnico";
	public static final String CTR_VALIDAR_CELULAR_UNICO = "/validarCelularUnico";
	public static final String CTR_VALIDAR_CELULAR = "/ctrValidarCelular";
	public static final String CTR_CORREO_ENVIAR = "/correos/enviar";
	public static final String CTR_MENSAJE_ENVIAR = "/ctrEnviarMensajes";
	public static final String CTR_MENSAJE_CONTRATO_ENVIAR = "/ctrEnviarMensajeContrato";

	public static final String CTR_CORREO_PLANTILLA_ENVIAR = "/correosPlantilla/enviar";
	public static final String CTR_CORREO_PLANTILLA_BIG_ENVIAR = "/correosPlantillaBig/enviar";
	public static final String CTR_BURO_HACER_CONSULTA = "/BuroDeCredito/hacerConsulta";
	public static final String CTR_BURO_HACER_CONSULTA_AVAL = "/BuroDeCredito/hacerConsultaAval";
	public static final String CTR_BURO_CONSULTA_AVAL_NOMBRE = "/BuroDeCredito/ConsultaBuroAval";
	public static final String CTR_BURO_INTERNO_CONSULTA_CLIENTE = "/BuroInterno/consultaCliente";
	public static final String CTR_BURO_ACTUALIZAR_PRODUCTO_CONSUMO = "/BuroCredito/ActualizarProductoConsumo";
	public static final String CTR_BURO_ACTUALIZAR_PRODUCTO_RESCATE = "/BuroCredito/ActualizarProductoRescate";
	public static final String CTR_BURO_COTIZADOR_ITALIKA_MX = "/BuroCredito/CotizadorItalikaMX";	
	public static final String CTR_CONSULTA_MARCAS_SOLICITUD = "/ctrMarcasSolicitud";
	public static final String CTR_DIGITALIZACION_DIGITALIZAR = "/digitalizar";
	public static final String CTR_DIGITALIZACION_DIGITALIZAR_DOCUMENTOS = "/digitalizarDocumentos";
	public static final String CTR_LOGIN = "/login";
	public static final String CTR_CALLCENTER_OBTENER_FOLIO = "/CallCenter/obtenerFolio";
	public static final String CTR_CALLCENTER_OBTENER_FOLIOS = "/CallCenter/obtenerFolios";

	public static final String CTR_CLIENTE_UNICO = "/ctrClienteUnico";

	public static final String CTR_CLIENTE_360 = "/consultaCliente360";

	public static final String CTR_CREDITOBDIGITAL = "/consultaCreditoBDigital";

	public static final String CTR_LINEA_CREDITO = "/ctrLineaCredito";

	public static final String CTR_ACTUALIZAR_ESTATUS_TIENDA = "/actualizaStatusTienda";
	public static final String CTR_ACTUALIZAR_PRODUCTO = "/actualizaProducto";
	public static final String CTR_CATEGORIA = "/ctrCategoria";
	public static final String CTR_SERVICIO_EXTERNO = "/servicioExterno";
	public static final String CTR_SERVICIO_TEST = "/test";
	public static final String CTR_SERVICIO_TEST2 = "/test2";
	public static final String CTR_SERVICIO_TEST3 = "/test3";
	public static final String CTR_SERVICIO_TEST_GENERICO = "/testGenerico";
	public static final String CTR_SERVICIO_TEST_GENERICO_2 = "/testGenerico2";
	public static final String CTR_SERVICIO_TESTBIG = "/testBig";
	public static final String CTR_SERVICIO_TEST_EXCEL = "/testExcel";
	public static final String CTR_ANTIGUEDAD_LCR="/testValidaAntiguedadLCR";

	public static final String CTR_OBTENERIP_TIENDA = "/obtenerIPTienda";

	public static final String CTR_SP_TIENDA = "/spTienda";

	public static final String CTR_CONSULTA_RENIEC = "/ctrReniec";

	public static final String CTR_CONSULTA_INFO_SOL_TIENDA = "/ctrConsultaInfoSolTienda";

	public static final String CTR_ACTUALIZACION_CU = "/ctrActualizacionCU";

	public static final String CTR_CONSULTA_INFO_SUCURSAL = "/ctrConsultaInfoSucursal";

	public static final String CTR_LIGAR_LCR = "/ctrLigarLCR";

	public static final String CTR_CONSULTA_TAZ_X_CU = "/consultaTarjetaXCU";
	
	public static final String CTR_CONSULTA_TAZ_MM18 = "/consultaTarjetaMM18";

	public static final String CTR_CANCELAR_TAZ_M121 = "/cancelarTarjetaM121";
	
	public static final String CONSULTAR_CANCELAR_TAZ = "/consultarCancelarTarjetaxCU";
	
	public static final String CTR_CONSULTA_CU_X_TAZ = "/consultaCUXTarjeta";

	public static final String CTR_CONSULTA_ESTATUS_TARJETA = "/consultaEstatusTarjeta";

	public static final String CTR_VALIDAR_TARJETA_CLIENTE = "/validarTarjetaCliente";

	public static final String CTR_CONSULTA_TAZ_M296 = "/consultaTarjetaPorClienteunico";

    public static final String CTR_CONSULTAR_CANCELAR_TAZ_M296 = "/consultaCancelarTarjetaPorClienteunico";
	       

	/**
	 * Controller utilizado para el proceso de liberaci�n sin tarjeta Azteca
	 */
	public static final String CTR_LIBERAR_LCRPEDIDO_SIN_TAZ = "/sinTarjetas";

	public static final String CTR_COTIZADOR = "/cotizadorItalika";
	// PERU

	public static final String CTR_SCORING_CONSULTA_PERU = "/Peru/ScoringMatrices/hacerConsulta";
	public static final String CTR_HOMONIMOS_CONSULTA_PERU = "/Peru/Homonimos/hacerConsulta";
	public static final String CTR_SOLICITUD_GUARDAR_PERU = "/Peru/Solicitud/guardarSolicitud";

	// BAZ - DIGITAL

	public static final String CTR_BAZDIGITAL_NUEVA_SOLICITUD = "/BazDigital/nuevaSolicitud";
	public static final String CTR_BAZDIGITAL_CONSULTA_TERMOMETROS = "/BazDigital/consultaTermometro";
	public static final String CTR_BAZDIGITAL_CONSULTA_VALIDACIONES_CLIENTE = "/BazDigital/consultaValidacionesCliente";
	public static final String CTR_BAZDIGITAL_CONSULTA_MONTOS = "/BazDigital/consultaMontos";
	public static final String CTR_BAZDIGITAL_INSERTA_MONTOS = "/BazDigital/insertaMontos";
	public static final String CTR_BAZDIGITAL_GUARDAR_ENCUESTA = "/BazDigital/guardarEncuesta";
	public static final String CTR_BAZDIGITAL_GENERAR_PEDIDO_QR1_QR2 = "/BazDigital/generarPedido";
	public static final String CTR_BAZDIGITAL_GENERAR_PEDIDO_QR3 = "/BazDigital/generarPedidoQR3";
	public static final String CTR_BAZDIGITAL_PEDIDO_QR3 = "/BazDigital/pedidosQR3";
	public static final String CTR_BAZDIGITAL_AGENDAR_LLAMADA = "/BazDigital/ctrAgendarLlamadaBazDigital";

	public static final String CTR_BAZDIGITAL_lIBERACION_ACTUALIZAR_HUELLAS = "/actualizarHuellasBazDigital";
	public static final String CTR_BAZDIGITAL_LIGAR_PEDIDO_EMPLEADO = "/BazDigital/ligarPedidoEmpleado";

	public static final String CTR_BAZDIGITAL_CONSULTA_BURO_EXTERNO = "/BazDigital/consultaBuroExterno";

	public static final String CTR_BAZDIGITAL = "/BazDigital";
	public static final String CTR_ACEPTA_PRODUCTO_RESCATE = "/BazDigital/aceptaProductoRescate";
	public static final String CTR_SURTIR_PEDIDO_ITALIKA = "/BazDigital/surtirPedidoItalika";
	public static final String CTR_CANCELAR_PEDIDO_ITALIKA = "/BazDigital/cancelarSurtimientoItalika";
	public static final String WS_SURTIMIENTO_ITALIKA = ":9050/ServiciosSurtimiento/WSSurtimientoContado.svc/json/AplicarSurtimientoItalika";
	public static final double MONTOS_MENORES = 5000;
	public static final double MONTOS_MAYORES = 70000;
	public static final int U_NEGOCIO_MONTOS_MENORES = 83;
	public static final int U_NEGOCIO_MONTOS_MAYORES = 4;

	// BAZDIGITAL: Proceso en Back

	public static final String CTR_BAZDIGITAL_BACK_CREAR_SOLICITUD = "/BazDigital/back/crearSolicitud";
	public static final String CTR_BAZDIGITAL_BACK_CONSULTA_BURO = "/BazDigital/back/consultaBuro";
	public static final String CTR_BAZDIGITAL_BACK_CONSULTA_BURO_COMPROBABLES = "/BazDigital/back/consultaBuroComprobables";
	public static final String CTR_BAZDIGITAL_BACK_CREAR_SOLICITUD_TIENDA = "/BazDigital/back/crearSolicitudTienda";
	public static final String CTR_BAZDIGITAL_BACK_AGENDAR_CITA = "/BazDigital/back/agendarCita";
	public static final String CTR_BAZDIGITAL_BACK_INFORMAR_PRODUCTO = "/BazDigital/back/informarProducto";
	public static final String CTR_BAZDIGITAL_BACK_INFORMAR_PRODUCTO_PORTALES = "/BazDigital/back/informarProductoPortales";
	public static final String CTR_BAZDIGITAL_BACK_BUSCA_SOLICITUD_X_CU = "/BazDigital/solicitudes";
	public static final String CTR_BAZDIGITAL_GUARDAR_COTIZACION = "/BazDigital/guardarContizacion";
	public static final String CTR_BAZDIGITAL_LIBERACION_MANUAL = "/BazDigital/liberacionManual";
	public static final String CTR_BAZDIGITAL_BACK_STATUS_CLIENTE = "/BazDigital/consultaStatusCliente";
	public static final String CTR_BAZDIGITAL_GUARDAR_TIPO_FLUJO = "/BazDigital/guardarTipoFlujo";
	public static final String CTR_BAZDIGITAL_ALTA_TIPO_FLUJO = "/BazDigital/altaTipoFlujo";

	// CALL CENTER

	public static final String CTR_CALLCENTER_OBTENER_DATOS_SOLICITUD = "/CallCenter/obtenerDatosTarjetas";
	public static final String CTR_CALLCENTER_ACTIVAR_TAZ = "/CallCenter/activarTarjeta";

	// GUARDAR TARJETA
	public static final String CTR_GUARDA_TARJETA_SOLICITUD = "/activacionTaz/guardarTarjeta";

	// BAZ TDC ORO
	public static final String CTR_ESTADO_CUENTA_TDC_ORO = "/EstadoCuenta/TDCOro";

	// PRESTAMOS ACTIVACION FOLIO UNICO
	public static final String CTR_PRESTAMOS_ACTIVACION_FLUJO_UNICO = "/Prestamos/ctrActivacionFlujoUnico";
	// PRESTAMOS FOLIO UNICO DATOS LIBERACION
	public static final String CTR_FLUJO_UNICO = "/FlujoUnico";
	// GENERAR FOLIO �NICO
	public static final String CTR_GENERAR_FOLIO_UNICO = "/folioUnico";
	public static final String MTD_GENERAR_FOLIO_UNICO = "/generarFolioUnico";
	// SECCION GUARDADITO
	public static final String CTR_SECCION_GUARDADITO = "/seccionGuardadito";
	public static final String MTD_GUARDAR = "/guardar";
	public static final String MTD_CONSULTAR = "/consultar";

	//

	// Compresor archivo
	public static final String CTR_COMPRESOR_ARCHIVOS = "/Compresor";

	// INDICADORES
	public static final String CTR_INDICADORES = "/Indicadores";

	// ACTUALIZA Y MARCA SOLICITUD
	public static final String CTR_ACTUALIZA_Y_MARCA_SOL = "/ActualizaYMarca";

	// GENERAR TABLA DE AMORTIZACION
	public static final String CTR_GENERAR_TABLA_AMORTIZACION = "/GenerarTablaAmortizacion";

	// Flujo Oferta
	public static final String CTR_FLUJO_OFERTA_DIAS = "/FlujoOferta/obtenerDias";
	public static final String CTR_FLUJO_OFERTA_CP = "/FlujoOferta/capacidadPago";
	public static final String CTR_FLUJO_OFERTA_COMPROBANTE = "/FlujoOferta/guardaComprobante";
	public static final String CTR_FLUJO_CONTEO_STATUS_MARCA = "/FlujoOferta/conteoStatusMarca";

	public static final String CTR_CATALOGOS = "/Catalogos";
	public static final String MTD_OBTENER_COLONIAS_POR_CP = "/coloniasPorCP";
	public static final String CTR_LINEA_PRODUCTO = "/LineaProducto";
	public static final String MTD_CONSULTA = "/consulta";
	public static final String CTR_REGLAS_RESCATE = "/reglas";
	public static final String MTD_REGLAS_RESCATE = "/rescate";
	public static final String CTR_REGLAS_RESCATE_FENIX_BANCO = "/reglas";
	public static final String MTD_REGLAS_RESCATE_FENIX_BANCO = "/rescateBancoFenix";
	public static final String CTR_REGLAS_RESCATE_FENIX_COMERCIO = "/reglas";
	public static final String MTD_REGLAS_RESCATE_FENIX_COMERCIO = "/rescateComercioFenix";

	public static final String CTR_ENCUESTAS_BURO = "/EncuestasBuro";
	public static final String MTD_OBTENER_ENCUESTA = "/ObtenerBateriaPreguntasRespuestas";
	public static final String MTD_OBTENER_EVALUACION_ENCUESTA = "/ObtenerEvaluacionBateria";
	/*
	 * METHOD REQUEST
	 */

	public static final String MTD_ELIMINAR_SOLICITUD = "/eliminarSolicitud";
	public static final String MTD_BUSCAR_CU = "/buscarCU";

	public static final String MTD_OBTENER_LCR_AUTORIZADA = "/obtenerDatosAutorizada";
	public static final String MTD_OBTENER_LCR_BLOQUEADA = "/obtenerDatosBloqueada";
	public static final String MTD_OBTENER_LCR_MICRONEGOCIO = "/consultaMicronegocio";

	public static final String CTR_BITACORA_ADN = "/BitacoraAdn";
	public static final String MTD_INSERTA_BITACORA = "/InsertaBitacoraAdn";
	public static final String MTD_CONSULTA_BITACORA = "/ConsultaBitacoraAdn";
	
	public static final String MTD_GUARDAR_SOLICITUD = "/guardarSolicitud";
	public static final String MTD_GUARDAR_SECCION_SOLICITUD = "/guardarSeccionSolicitud";
	public static final String MTD_GUARDAR_SECCION_SOLICITUD_INVESTIGACION = "/guardarSeccionInvestigacion";
	public static final String MTD_VALIDAR_CELULAR = "/validarCelular";
	public static final String MTD_BUSCAR_SOLICITUD = "/buscarSolicitud";
	public static final String MTD_BUSCAR_SOLICITUDES = "/buscarSolicitudes";
	public static final String MTD_BUSCAR_SOLICITUD_ID = "/buscarSolicitudId";
	public static final String MTD_BUSCAR_SOLICITUD_BAZD = "/buscarSolicitudBazDig";
	public static final String MTD_BUSCAR_SOLICITUD_BAZ = "/buscarSolicitudB";
	public static final String MTD_BUSCAR_TARJETAS_B = "/buscarTarjetasB";
	public static final String MTD_ACTUALIZAR_CU_SOLICITUD = "/mtdActualizarSolicitudCU";
	public static final String MTD_GENERAR_DESDE_RECHAZADA = "/mtdGenerarSolicitudDesdeRechazada";
	public static final String MTD_VALIDAR_DESDE_RECHAZADA = "/mtdValidarSolicitudDesdeRechazada";
	public static final String MTD_ALTA_CU_TIENDA = "/altaCUTienda";

	public static final String MTD_DATOS_EMPLEO = "/datosEmpleo";
	public static final String MTD_INGRESOS_EGRESOS = "/ingresosEgresos";
	public static final String MTD_CONSULTA_HOMONIMOS = "/mtdConsultaHomonimos";
	public static final String MTD_OBTENER_HOMONIMOS = "/mtdObtenerHomonimos";
	public static final String MTD_OBTENER_HOMONIMOS_CAMBACEO = "/mtdObtenerHomonimosCambaceo";
	public static final String MTD_CONSULTA_INE = "/mtdConsultarINE";
	public static final String MTD_CONSULTA_FOTOCU = "/mtdConsultaFoto";
	public static final String MTD_CONSULTA_POR_CU = "/mtdConsultaFotoCU";
	public static final String MTD_ACTUALIZAR_FOTO = "/actualizaFoto";
	public static final String MTD_ACTUALIZA_STATUS_FOTO = "/actualizaStatusFoto";
	public static final String MTD_ORIGEN_SOLICITUD = "/origenSolicitud";
	public static final String MTD_OBTTENER_DATOS_HOMONIMOS = "/mtdObtenerDatosHomonimos";
	public static final String MTD_OBTTENER_DATOS_HOMONIMOS_TARJETAS = "/mtdObtenerDatosHomonimosTarjetas";
	public static final String MTD_OBTTENER_SOLICITUD = "/mtdObtenerSolicitud";
	public static final String MTD_GENERAR_SOLICITUD = "/mtdGenerarSolicitudPrestamo";
	public static final String MTD_ACT_VAL_SOL = "/mtdActValSol";
	public static final String MTD_FOTO_CU_GUARDAR = "/guardar";
	public static final String MTD_GUARDAR_CADENA = "/guardarCadena";
	public static final String MTD_OBTENER_DATOS_ASESOR = "/mtdObtenerDatos";
	public static final String MTD_OBTENER_DATOS_ASESOR_BAZDIGITAL = "/mtdObtenerDatosAsesorDigital";
	public static final String MTD_OBTENER_FECHA_VISITA_ASESOR_DIGITAL = "/mtdObtenerFechaCitaAsesorBazDig";
	public static final String MTD_OBTENER_FOTO_ASESOR = "/mtdObtenerFotoAsesor";
	public static final String MTD_OBTENER_SOLICITUDES_ASESOR = "/mtdObtenerSolicitudesAsesor";
	public static final String MTD_RECOMPRA = "/mtdRecompra";
	public static final String MTD_RESULTADO_BURO = "/resultadoConsultaBuro";
	public static final String MTD_PRODUCTOS_RESCATE = "/BuroDeCredito/obtenerProductosRescate";
	public static final String MTD_OBTENER_PLAZOS_MONTOS = "/getMontosPlazos";
	public static final String MTD_RESULTADO_BURO_REPORTE = "/resultadoBuro";

	public static final String MTD_DATOS_RENIEC = "/obtenerDatosReniec";
	public static final String MTD_DATOS_RENIEC_ENDEUDAMIENTO = "/getEndeudamiento";

	public static final String MTD_OBTENER_INFO_VTA_PRESUP_TIENDA = "/mtdObtenerInfoVtaPresup";
	public static final String MTD_OBTENER_INFO_PEDIDO = "/mtdObtenerInfoPedido";

	// AVAL
	public static final String MTD_GUARDAR_DATOS_AVAL = "/guardarDatosAval";
	public static final String MTD_OBTENER_DATOS_AVAL = "/obtenerDatosAval";

	// EXPEDIENTES
	public static final String MTD_GUARDAR_EXPEDIENTES = "/guardarExpedientes";

	// SIMULACION
	public static final String MTD_GUARDAR_SIMULACION = "/guardarSimulacion";
	public static final String MTD_OBTENER_SIMULACION = "/obtenerSimulacion";
	public static final String MTD_VALIDAR_CODIGO_CELULAR = "/validarCodigoCelular";
	public static final String MTD_REENVIAR_CODIGO_CELULAR = "/reenviarCodigoCelular";
	public static final String MTD_TEST_CODIGO_CELULAR = "/testCodigoCelular";

	// AGENDAR CITA
	public static final String MTD_AGENDAR_CITA = "/agendarCita";
	public static final String MTD_AGENDAR_CITA_BAZ_DIGITAL = "/agendarCitaBazDigital";
	public static final String MTD_FECHAS_CITAS_SOLICITUDES = "/fechasCitaSolicitudes";

	// AGENDAR LLAMADA
	public static final String MTD_AGENDAR_LLAMADA = "/agendarLlamada";
	public static final String MTD_AGENDAR_LLAMADA_BAZ_DIGITAL = "/agendarLlamadaBazDigital";

	// LIBERACION
	public static final String MTD_LIBERAR = "/liberar";
	// DIGITALIZACION
	public static final String MTD_ACTUALIZAR_CUENTA_CU = "/actualizarCuentaCU";
	public static final String MTD_GENERAR_CONTRATOS_DIGITALZIADOS = "/generarContratosDigitalizados";

	// SOLICITUDES
	public static final String MTD_OBTENER_SOLICITUDES_PROCESO = "/obtenerSolicitudesEnProceso";

	// CONSULTA CLIENTE UNICO
	public static final String MTD_CONSULTAR_CU_EMAIL = "/mtdConsultaClienteEmail";
	public static final String MTD_CONSULTAR_CU_TELEFONO = "/mtdConsultaClienteTelefono";

	public static final String MTD_CONSULTA_FOLIO_CU = "/mtdConsultaFolioCU";
	//Prueba Respuesta Folio ID Complementaria
	public static final String MTD_CONSULTA_FOLIO_CU_COMPLEMENTARIA = "/mtdConsultaFolioCUComplementaria";

	public static final String MTD_GUARDAR_DIA_PAGO = "/guardarDiaPago";

	public static final String MTD_OBTENER_ESTATUS_LCR = "/obtenerEstusLCR";

	public static final String MTD_ACTUALIZAR_ESTATUS = "/actualizarStatus";
	public static final String MTD_ACTUALIZAR_ESTATUS_RENDICION = "/actualizarStatusRendicion";
	public static final String MTD_ACTUALIZAR_PRODUCTO = "/actualizarProducto";

	public static final String MTD_RESET_CACHE = "/resetCache";
	public static final String MTD_RESET_BANDERA_CONFIGURADOR = "/reiniciarBanderaConfigurador";
	public static final String MTD_CONSULTA_BANDERA_CONFIGURADOR = "/estadoBanderaConfigurador";

	public static final String MTD_RESET_CACHE_CATEGORIAS = "/resetCacheCategorias";

	public static final String MTD_ENVIAR_SOLICITUDES = "/enviarSolicitudes";

	public static final String MTD_CU_POR_DIRECCION = "/cuPorDireccion";

	public static final String MTD_FONETICA_DOMICILIO_ADN = "/foneticaDomicilioADN";

	public static final String MTD_PEDIDOS_POR_CU = "/pedidosPorCU";

	public static final String MTD_SOLICITUDES_POR_CU = "/solicitudesPorCU";

	public static final String MTD_BUSCADOR_CLIENTES_RECOMPRA = "/buscadorClientesRecompra";

	public static final String MTD_CLIENTE_COMPRA = "/clienteCompra";

	public static final String MTD_BUSCADOR_CLIENTES_RENAPO = "/buscaRENAPO";
	public static final String MTD_BUSCADOR_CLIENTES_RENAPO_ACT_DATOS = "/buscaRENAPOActDatos";
	public static final String MTD_BUSCADOR_CLIENTES_360 = "/busca360";

	public static final String MTD_OBTENER_INFORMACION = "/obtenerInformacion";

	// Cambiar Estatus de Solicitud en Tienda
	public static final String MTD_CAMBIAR_ESTATUS = "/cambiarEstatusSol";

	// ACTIALIZA CU
	public static final String MTD_ACTUALIZA_DATOS = "/mtdActualizaDatos";
	public static final String MTD_ACTUALIZA_HUELLAS_OT = "/mtdActualizaHuellasOT";
	public static final String MTD_ACTUALIZA_FOTO_CU = "/mtdActualizaFotoCUCentral";
	public static final String MTD_ACTUALIZA_LIGAR_AVALES = "/mtdActualizaLigarAvales";
	public static final String MTD_LIGAR_LCR = "/mtdLigarLCR";

	/**
	 * M�todo utilizado para el proceso de liberaci�n sin tarjeta Azteca
	 */
	public static final String MTD_LIBERAR_LCRPEDIDO_SIN_TAZ = "/liberarLCRGenerarPedidoCallCenter";

	//

	public static final String MTD_COTIZAR_ITALIKA = "/consultaItalika";
	public static final String MTD_BUSCAR_PRODUCTOS_ITALIKA = "/buscarProductos";
	public static final String MTD_OBTENER_TASAS_ITALIKA = "/obtenerTasas";
	public static final String MTD_CONSULTA_NOMBRE_PRODUCTO = "/consultaxNombreProducto";

	// PRESTAMOS ACTIVACION FOLIO UNICO
	public static final String MTD_ACTIVACION_POR_FOLIO_UNICO = "/mtdActivacionPorFolioUnico";
	public static final String MTD_LIGA_FOLIO_UNICO = "/mtdLigaFolioUnico";
	public static final String MTD_INFORMAR_SURTIMIENTO = "/informarSurtimiento";

	public static final String MTD_FLUJO_UNICO_GUARDAR_DATOS_LIBERACION = "/guardarDatosLiberacion";

	// MESA DE CONTROL
	public static final String MTD_MESACONTROL_GENERICO = "/dictaminacionMCO";
	public static final String MTD_MESACONTROL_DICTAMINACION_GENERICO = "/dictaminacionMCO";
	public static final String MTD_MESACONTROL_CONDICIONAMIENTO_GENERICO = "/condicionamientoMCO";
	public static final String MTD_MESACONTROL_VALIDA_EXPEDIENTE_MCO = "/validaExpedienteMCO";
	public static final String MTD_MESACONTROL_CONDICIONAMIENTO_EXPEDIENTE_MCO = "/condicionamientoGenericoMCO";
	public static final String MTD_AUTORIZA_SOLICITUD_POR_CAMBIO_CDP="/actualizaStatusPorCambioCPD";
	public static final String MTD_RECHAZO_SOLICITUD_POR_CAMBIO_CDP="/rechazoPorCambioCPD";
	
	public static final String MTD_MESACONTROL_VALIDAR_VISITA = "/validarVisita";
	public static final String MTD_MESACONTROL_REPORGRAMAR_VISITA = "/reprogramarVisita";
	public static final String MTD_MESACONTROL_CLIENTE_NO_ES_MISMA_PEROSNA = "/cliente/NoEsMismaPersona";
	public static final String MTD_MESACONTROL_EXPEDIENTE_RECHAZO_GERENTE = "/expedienteRechazadoGerente";
	public static final String MTD_MESACONTROL_VALIDAR_NOMBRE_REAL = "/validarNombreReal";
	public static final String MTD_MESACONTROL_FAMILIAR_EN_PCJ_RMD = "/familiarPCJ_RMD";
	public static final String MTD_MESACONTROL_CLIENTE_INFORMACION_FALSA = "/cliente/informacionFalsa"; // -->Documentos
																										// Falsos
	public static final String MTD_MESACONTROL_FALSEO_INFORMACION = "/cliente/datosFalsos"; // -->Cliente
																							// Falseo
																							// Informacion

	public static final String MTD_MESACONTROL_REFERENCIAS = "/contactarReferencias";
	public static final String MTD_MESACONTROL_VALIDACION_TELEFONO = "/validacionTelefono";
	public static final String MTD_MESACONTROL_REPROGRAMAR_VISITAS = "/reprogramarVisitas";
	public static final String MTD_MESACONTROL_NO_ES_LA_MISMA_PERSONA = "/noEsLaMismaPersona";
	public static final String MTD_MESACONTROL_FAMILIAR_RMD_PCJ_LEGAL = "/FamiliarRmdPcjLegal/{idSolicitud}";

	public static final String MTD_MESACONTROL_BATCH_PENDIENTES = "/SolicitudesPendientes";
	public static final String MTD_MESACONTROL_GENERA_FOLIO_12K = "/generaFolioSurtimiento12K";
	public static final String MTD_MESACONTROL_INGRESOS_COMP = "/enviarMCOIngresosCompMayoresA20K";
	public static final String MTD_MESACONTROL_INGRESOS_NO_COMP = "/enviarMCOIngresosNoCompValidaExpediente";
	public static final String MTD_MESACONTROL_VALIDA_SOLICITUD = "/validaStatusSolicitudNOC";
	public static final String INVESTIGACION_MCO_RECHAZA_SOLICITUD= "/MesaCredito/rechazaSolicitud";

	public static final String CTR_MESACONTROL = "/MesaControl";
	public static final String CTR_MCO = "/MCO";
	public static final String MTD_MESACONTROL_REPROCESO_JVC="/reprocesoRechazoJV";
	public static final String MTD_MESACONTROL_BENEFICIOS_EMPLEADO="/beneficiosEmpleados/generaFolioMCO";
	public static final String MTD_MESACONTROL_DICTAMINACION="/condicionamiento";

	public static final String CTR_BENEFICIOS = "/beneficiosEmpleados";
	public static final String MTD_BENEFICIOS_GUARDA_BURO = "/consultaBuro/actualizarCDP";
	
	// Compresor archivo
	public static final String MTD_COMPRESOR_ARCHIVO = "/mtdCompresorArchivo";

	// BackOffice- Rechazo por Gerente
	public static final String MTD_RECHAZO_POR_GERENTE = "/backOffice/mtdRechazoPorGerente";
	public static final String MTD_RECHAZO_POR_GERENTE_FRONT = "/RechazoGerenteFront";
	public static final String MTD_RECHAZO_POR_GERENTE_FRONT_CONDICIONAMIENTO = "/RechazoGerenteFrontCondicionado";
	public static final String MTD_RECHAZO_POR_GERENTE_FRONT_CDT = "/RechazoGerenteFrontCDT";
	// BackOffice- Validar por Nombre
	public static final String MTD_VALIDAR_POR_NOMBRE = "/backOffice/mtdValidarPorNombre";
	// BackOffice- Validar por Visita
	public static final String MTD_VALIDAR_POR_VISITA = "/backOffice/mtdValidarPorVisita";
	// BackOffice- Validar por Visita
	public static final String MTD_VALIDAR_CLIENTE_FALSEO_INFORMACION = "/backOffice/mtdValidarClienteFalseoInformacion";

	/**
	 * M&eacute;todo para actualizar solicitud por Mesa de Control.
	 */
	public static final String MTD_ACTUALIZAR_SECCION_MESA = "/actualizarSeccionMesa";
	// Dictaminacion
	public static final String MTD_REGISTRA_DICTAMINACION = "/registraDictaminacion";
	// Metodo para Validar la parametrizacion por Region
	public static final String MTD_CONSULTA_FUNCIONALAD_REGION = "/consultaFuncionalidadRegion";

	//
	public static final String MTD_OBTENER_DATOS_SOL = "/obtenerDatosSol";

	public static final String CTR_MONITOREO = "/ctrMonitoreo";
	public static final String CTR_CTES_SIN_CTEAL = "/ctesSinCteAlnova";

	// GUARDA INDICADORES
	public static final String MTD_GUARDA_INDICADORES = "/guardaIndicadores";

	// ACTUALZA Y MARCA LAS SOLICITUDES
	public static final String MTD_ACTUALIZA_Y_MARCA_SOL = "/actualizaymarcasol";

	//
	public static final String CTR_STATUS_LCR = "/statusLCR";

	// GENERAR TABLA DE AMORTIZACION
	public static final String MTD_TABLA_AMORTIZACION = "/mtdTablaAmortizacion";
	
	// INSERTA MARCAS
	public static final String CTR_SERVICIOS_MARCAS = "/marcas";
	

	/*
	 * CONFIGURACION DE PRUEBAS
	 */

	public static final String CTR_SERVICIOS_PRUEBAS_GENERICAS = "/pruebas";
	public static final String MTD_WS_PG_CREAR_SOLICITUD_LIBERACION = "/crearSolicitudLiberacion";
	public static final String MTD_HUELLAS442 = "/huellas442";
	public static final String MIS_PRUEBAS = "/misPruebas";
	//
	public static final String CTR_BITACORA_EDICION_DATOS = "/bitacoraEdicionDatos";
	public static final String MTD_CONSULTA_BITACORA_EDICION = "/consultarEdicionDatosNOC";
	public static final String MTD_ALTA_EDICION_BLOQUEADOS = "/altaEdicionBloqueado";
	public static final String MTD_VALIDA_SECCION = "/validaSeccionEditada";

	/*
	 * AGENDA CITA SRC
	 */
	public static final String CTR_SRC = "/src";
	public static final String MTD_DICTAMINACION_SRC = "/dictaminacionSRC";

	/**
	 * RECUPERAR SOLICITUD POR SUCURSAL
	 */
	public static final String CTR_MIGRACION = "/ctrMigracion";
	public static final String MTD_MIGRACION_SOLICITUD = "/migracionSolicitud";

	public static final String DATOS_CARATULA = "datosCaratula";
	public static final String OBTENERTASAS_Y_CAT = "obtenerTasasYCAT";
	
	/*
	 * CONFIGURACION OBTENIDA DESDE PROPERTIES
	 */

	public static final int DOCUMENTO_PENDIENTE_DE_CAPTURAR = 1;
	public static final int DOCUMENTO_CAPTURADO = 2;
	public static final int NO_REQUERIDO = 3;
	public static final int PENDIENTE_DE_VALIDAR = 4;
	public static final int RECHAZADO = 5;
	public static final int VALIDADO = 6;

	/*
	 * Usuario para consumir servicios de cliente �nico
	 */
	public static final String USERCRECU = "USRCREDITO";
	public static final String USERCREDCUAVAL = "USRCREDITOMOC";
	public static final String USRCREDCAMBACEO = "USRCREDCAMBACEO";
	public static final String USRCREDITOTOKEN = "USRCREDITOTOKEN";
	public static final String USRCREDITOORO = "USRCREDITOORO";
	public static final String IP_VALIDA_CU = "10.53.35.61";

	public static final String SCHEMA_JSON = "/JSONSCHEMA/SolicitudSchema.json";

	/*
	 * CONFIGURACION BASE DE DATOS
	 */

	// BD produccion
	// public static final String DATABASE ="CREDITOAPP";

	// BD desarrollo
	public static String DATABASE = "CRCBDDES";
	// public static final String BD_SCHEMA = "USR267481";
	public static final String BD_SCHEMA = "SC_SOLCRDA";
	public static final String BD_SCHEMA_BAZ = "SC_AUTOCRED";

	// Procedimientos BD

	// STORED MAESTRO PARA LA SOLICITUD
	public static final String BD_CATALOGO_MAESTRO = "GSCRSOLPKG0035";
	public static final String BD_CATALOGO_GUARDAR_DRP = "GSCRSOLPKG0024_DRP";
	public static final String SP_MAESTRO_SOLICITUD = "GSCRSOLSPM0001";

	// PARA GENERAR SOLICITUDEs
	public static final String BD_CATALOGO_GENERAR_SOLICITUDES = "GSCRSOLPKG0032";
	public static final String SP_GENERAR_POR_BUSQUEDA_CU = "GSCRSOLSPM0001";

	// PARA OBTENER SOLICITUDES
	public static final String PAQ_OBTENER_SIMULACIONES = "GSCRSOLPKG0037";
	public static final String SP_OBTENER_SIMULACIONES = "GSCRSOLSPC0005";

	public static final String PAQ_OBTENER_SOLICITUDES_POR_SUCURSAL = "GSCRSOLPA0109";
	public static final String PAQ_OBTENER_SOLICITUDES_POR_SUCURSAL_SIN_LCR = "GSCRSOLPA0143";
	public static final String SP_OBTENER_SOLICITUDES_POR_SUCURSAL = "GSCRSOLSPM0001";

	public static final String PAQ_OBTENER_SOLICITUDES_POR_SUCURSAL_Y_NOMBRE = "GSCRSOLPA0210";
	public static final String SP_OBTENER_SOLICITUDES_POR_SUCURSAL_Y_NOMBRE = "GSCRSOLSPM0001";

	public static final String PAQ_CONSULTA_SOLICITUD = "GSCRSOLPKG0066";
	public static final String SP_BUSCAR_SOLICITUD_POR_ID = "GSCRSOLSPI0003";

	public static final String PAQ_INVESTIGACION = "GSCRSOLPKG0107";
	public static final String SP_GUARDAR_DATOS_INVESTIGACION = "GSCRSOLSPM0001";

	// PARA REALIZAR BUSQUEDAS
	public static final String BD_CATALOGO_BUSQUEDAS = "GSCRSOLPKG0033";
	public static final String SP_BUSCAR_POR_ID_SOLICITUD = "GSCRSOLSPC0001";
	public static final String SP_BUSCAR_POR_CELULAR = "GSCRSOLSPC0003";

	// CONSULTAR CELULAR UNICO
	public static final String PAQ_CELULAR_UNICO = "GSCRSOLPA0180";
	public static final String SP_CELULAR_UNICO = "GSCRSOLSPM0002";

	// VALIDAR CELULAR UNICO
	public static final String PAQ_VALIDAR_CELULAR_UNICO = "GSCRSOLPA0181";
	public static final String SP_VALIDAR_CELULAR_UNICO = "GSCRSOLSPM0001";

	// CONSULTA SOLICITUDES GCC
	public static final String PAQ_CONSULTA_SOLICITUD_GCC_REGION_RANGO = "GSCRSOLPA0200";
	public static final String SP_CONSULTA_SOLICITUD_GCC_REGION_RANGO = "GSCRSOLSPM0001";

	// CONSULTA GENERO CLIENTE
	public static final String PAQ_CONSULTA_GENERO = "GSCRSOLPA0208";
	public static final String SP_CONSULTA_GENERO = "GSCRSOLSPM0001";

	// PROCESO SERVICIO
	public static final String PAQ_PROCESO_SERVICIO = "GSCRSOLPA0222";
	public static final String SP_PROCESO_SERVICIO = "GSCRSOLSPM0001";

	// SOLICITUD TIENDA
	public static final String PAQ_SOLICITUD_TIENDA_NEW = "GSCRSOLPA0227";
	// GUARDAR SOLICITUD TIENDA
	public static final String SP_GUARDAR_SOLICITUD_TIENDA = "GSCRSOLSPM0001";
	// CONSULTA SOLICITUD TIENDA
	public static final String SP_CONSULTA_SOLICITUD_TIENDA = "GSCRSOLSPC0002";

	// GUARDAR XML
	public static final String BD_CATALOGO_GUARDAR = "GSCRSOLPKG0024";
	public static final String SP_GUARDAR_SOLICITUD = "GSCRSOLSPM0001";

	// OBTNER CITAS ASESOR
	public static final String PAQ_CATALOGO_ASESOR = "GSCRSOLPKG0040";
	public static final String SP_OBTENER_CITAS_ASESOR = "GSCRSOLSPC0001";

	// OBTENER SOLICITUDES POR ASESOR
	public static final String PAQ_OBTENER_SOLICITUDES_ASESOR = "GSCRSOLPKG0063";
	public static final String PAQ_OBTENER_SOLICITUDES_ASESOR_SIN_LCR = "GSCRSOLPA0146";
	public static final String SP__OBTENER_SOLICITUDES_ASESOR = "GSCRSOLPAM0003";

	// OBTENER SOLICITUDES de la sucursal
	public static final String PAQ_OBTENER_SOLICITUDES_DE_SUCURSAL = "GSCRSOLPA0117";
	public static final String PAQ_OBTENER_SOLICITUDES_DE_SUCURSAL_SIN_LCR = "GSCRSOLPA0145";
	public static final String SP__OBTENER_SOLICITUDES_DE_SUCURSAL = "GSCRSOLPAM0001";

	public static final String PAQ_CONSULTA_FECHA_CITA_ASESOR = "GSCRSOLPKG0061";
	public static final String SP_CONSULTA_FECHA_CITA_ASESOR = "GSCRSOLPAC0001";

	// PARA GUARDAR DIA DE PAGO
	public static final String PAQ_GUARDAR_DIA_PAGO = "GSCRSOLPKG0049";
	public static final String SP_GUARDAR_DIA_PAGO = "GSCRSOLSPI0001";

	// PARA OBTENER DIA DE PAGO
	public static final String PAQ_OBTENER_DIA_PAGO = "GSCRSOLPKG0106";
	public static final String SP_OBTENER_DIA_PAGO = "GSCRSOLSPC0003";

	// PARA OBTENER SOLICITUDES
	public static final String PAQ_RENDICION = "GSCRSOLPKG0043";
	public static final String SP_ACTUALIZAR_ESTATUS_TIENDA = "GSCRSOLPRC0001";

	// PARA OBTENER TARJETAS DE UNA SOLICITUD
	public static final String PAQ_CONSULTAR_TAZ_Y_GUARDADITO = "GSCRSOLPKG0119";
	public static final String SP_CONSULTAR_TAZ_Y_GUARDADITO = "GSCRSOLSPC0001";

	// PARA GUARDAR UNA TARJETA EN UNA SOLICITUD
	public static final String PAQ_GUARDAR_TAZ_Y_GUARDADITO_EN_SOLICITUD = "GSCRSOLPA0118";
	public static final String SP_GUARDAR_TAZ_Y_GUARDADITO_EN_SOLICITUD = "GSCRSOLPAM0001";

	// Varios SP
	public static final String BD_CATALOGO_VARIOS = "GSCRSOLPKG0036";
	public static final String BD_CATALOGO_AGENDAR_CITA="GSCRSOLPA000348";
	public static final String SP_AGREGAR_CITA = "GSCRSOLSPI0003";

	public static final String SP_OBTENER_DATOS_COMPARACION = "GSCRSOLPKG0037";
	public static final String PAQ_OBTENER_DOCTOS_VALIDACION = "GSCRSOLPKG0038";

	public static final String PAQ_OBTENER_DATOS_CONEXION_SUCURSAL = "GSCRSOLPKG0041";
	public static final String SP_OBTENER_DATOS_CONEXION_SUCURSAL = "GSCRSOLSPC0005";
	public static final String PAQ_INSERTA_TICKET = "GSCRSOLPA0119";
	public static final String SP_INSERTA_TICKET = "GSCRSOLPAM0001";

	/* GUARDAR PETICION HUELLAS */
	public static final String PAQ_PETICION_HUELLAS = "GSCRSOLPKG0050";
	public static final String SP_PETICION_HUELLAS = "GSCRSOLPAM0001";
	public static final String SP_CONSULTA_HUELLAS = "GSCRSOLSPC0001";

	/* GUARDAR SOLICITUD TIENDA */
	public static final String PAQ_SOLICITUD_TIENDA = "GSCRSOLPKG0051";
	public static final String SP_GUARDAR_SOL_TIENDA = "GSCRSOLSPM0025";

	// REQUEST 5 MATRICES
	public static final String PAQ_REQUEST_5_MATRICES = "GSCRSOLPKG0033";
	public static final String SP_REQUEST_5_MATRICES = "GSCRSOLSPC0002";

	// REQUEST 5 MATRICES
	public static final String PAQ_REQUEST_5_MATRICES_BAZDIGITAL = "GSCRSOLPA0126";
	public static final String SP_REQUEST_5_MATRICES_BAZDIGITAL = "GSCRSOLSPC0002";

	// OBTENER INFO ULTIMA CONSULTA BURO
	public static final String PAQ_OBTENER_ULTIMA_INFO_CONSULTA_BURO = "GSCRSOLPKG0043";
	// public static final String PAQ_OBTENER_ULTIMA_INFO_CONSULTA_BURO =
	// "GSCRSOLPKG0041";
	public static final String SP_OBTENER_ULTIMA_INFO_CONSULTA_BURO = "GSCRSOLSPC0003";
	// public static final String SP_OBTENER_ULTIMA_INFO_CONSULTA_BURO =
	// "GSCRSOLSPC0002";

	// GUARDAR CONSULTA BURO Y SCORE
	public static final String PAQ_GUARADR_CONSULTA_BURO_Y_SCORE = "GSCRSOLPKG0043";
	public static final String SP_GUARADR_CONSULTA_BURO_Y_SCORE = "GSCRSOLSPI0002";
	// public static final String PAQ_GUARADR_CONSULTA_BURO_Y_SCORE =
	// "GSCRSOLPKG0041";
	// public static final String SP_GUARADR_CONSULTA_BURO_Y_SCORE =
	// "GSCRSOLSPM0001";

	// REQUEST BURO
	public static final String PAQ_REQUEST_BURO = "GSCRSOLPKG0039";
	public static final String SP_REQUEST_BURO = "GSCRSOLSPC0002";

	// Response Buro
	public static final String PAQ_OBTENER_RESPUESTA_BURO = "GSCRSOLPKG0041";
	public static final String SP_OBTENER_RESPUESTA_BURO = "GSCRSOLSPC0004";

	// Response Buro CU
	public static final String PAQ_OBTENER_RESPUESTA_BURO_CU = "GSCRSOLPKG0101";
	public static final String SP_OBTENER_RESPUESTA_BURO_CU = "GSCRSOLSPC0004";

	// Consulta STATUS SOL POR CU PARA HOMONIMOS
	public static final String PAQ_CONSULTA_STATUS_CU = "GSCRSOLPKG0102";
	public static final String SP_CONSULTA_STATUS_CU = "GSCRSOLSPC0001";

	// Obtener peticiones autorizadas y liberadas.
	public static final String PAQ_CONSULTA_SOLICITUD_TERMINALES = "GSCRSOLPKG0066";
	public static final String SP_CONSULTA_SOLICITUD_TERMINALES = "GSCRSOLSPC0004";
	// Para Actualizar idProducto
	public static final String BD_ACTUALIZAR_ID_PRODUCTO = "GSCRSOLPKG0106";
	public static final String SP_ACTUALIZAR_ID_PRODUCTO = "GSCRSOLSPU0001";

	// Para Actualizar idProducto
	public static final String PAQ_GUARDAR_TAZ = "GSCRSOLPKG0106";
	public static final String SP_GUARDAR_TAZ = "GSCRSOLSPM0002";

	// MODIFICAR TAG DE XML POR RUTA
	public static final String PAQ_MODIFICAR_TAG_XML_RUTA = "GSCRSOLPKG0063";
	public static final String SP_MODIFICAR_TAG_XML_RUTA = "GSCRSOLPAM0001";

	//
	public static final String PAQ_MONITOREO = "GSCRSOLPA0127";
	public static final String SP_MONITOREO_C0001 = "GSCRSOLSPC0001";

	// OFERTA 30 DIAS
	public static final String PAQ_DIAS_LIBERADA = "GSCRSOLPA0162";
	public static final String SP_DIAS_LIBERADA = "GSCRSOLPAC0002";
	// Veces que solicitud ha estado en alguna marca o status
	public static final String SP_CONTEO_STATUS_MARCA = "GSCRSOLPAC0003";

	// Saber dias de rechazo de la solicitud
	public static final String PAQ_DIAS_RECHAZO_SOL = "GSCRSOLPA0128";
	public static final String SP_DIAS_RECHAZO_SOL = "GSCRSOLSPC0001";

	//
	public static final String PAQ_STATUS_LCR = "GSCRSOLPA0141";
	public static final String SP_STATUS_LCR_M0001 = "GSCRSOLSPM0001";

	// Access Token
	public static final String PAQ_ACCESS_TOKEN = "GSCRSOLPA0194";
	public static final String SP_ACCESS_TOKEN_CONSULTA = "GSCRSOLSPM0001";
	public static final String SP_ACCESS_TOKEN_ALTAMODIFICA = "GSCRSOLSPM0003";

	// OBTNER CONFIGURACION HILOS QUARTZ
	public static final String PAQ_CONFIGURACION_HILOS_QUARTZ = "GSCRSOLPA0202";
	public static final String SP_CONFIGURACION_HILOS_QUARTZ = "GSCRSOLSPM0001";

	// Consultar Historico Cambio Producto
	public static final String PAQ_HISTORICO_CAMBIO_PRODUCTO = "GSCRSOLPA0255";
	public static final String SP_HISTORICO_CAMBIO_PRODUCTO = "GSCRSOLSPM0001";

	// Estatus seguimiento
	public static final int ID_SEGUIMIENTO_PRE_AUTORIZADA = 6;

	// FolioConsultaBuro
	public static final String FOLIO_CONSULTA_BURO_DEFAULT = "1";

	// BuroConsultado
	public static final int BURO_CONSULTADO = 1;

	// id Producto Prestamo TODO corroborar info
	public static final int ID_PRODUCTO_PRESTAMOS_MENORES_Y_MAYORES = 24;

	// ID COLOR VERDE FUERTE
	public static final int ID_COLOR_VERDE_OBSCURO = 1;

	// ID COLOR VERDE
	public static final int ID_COLOR_VERDE = 2;

	// ID COLOR VERDE CLARO
	public static final int ID_COLOR_VERDE_CLARO = 3;

	// ID COLOR ROJO
	public static final int ID_COLOR_ROJO = 6;

	// TODO
	// consulta por tarjeta
	public static final int OPCION_CONSULTA_POR_TARJETA = 3;
	// ligar tarjeta
	public static final String OPCION_LIGAR_TARJETA = "S";

	// ID TIPO TARJETAS
	public static final int ID_TARJETA_AZTECA = 42;
	public static final String NOMBRE_BD_TARJETA_AZTECA = "TARJETA AZTECA";
	// TODO
	public static final int ID_TARJETA_GUARDADITO = 43;
	public static final String NOMBRE_BD_TARJETA_GUARDADTIO = "GUARDADITO";
	// ID TIPO TARJETAS para callcenter
	public static final int ID_TARJETA_AZTECA_CALL_CENTER = 1;
	public static final int ID_TARJETA_GUARDADITO_CALL_CENTER = 2;

	// TIPO DOCUMENTO
	public static final int ID_IDENTIFICACION_OFICIAL_CLIENTE = 1;
	public static final int ID_IDENTIFICACION_OFICIAL_AVAL = 7;

	// CLAVES DE FRAUDE RESPUESTA BURO
	public static final String CLAVES_FRAUDE_RECHAZO = "FD_RI_UP_SG";
	public static final String CLAVES_FRAUDE_VALIDA_RECHAZO = "CV_IM_NV_PC_VR_FR_IS_RN_IR_PS_LC_RV_SR";
	public static final String CLAVES_FRAUDE_VALIDA_RECHAZO_CON = "CV_IM_NV_PC_VR_FR_IS_RN_IR_PS";

	/* Variables para envios */
	public static final String TOKEN_ARQSEND_DESARROLLO = "IdKK0iZ6roxbUiA5na2wTUKz84FnafFVM4qHtZwnBCmVY6w+EeELInYaQ034SyKj5LvpTzKb6LNl6n3jL+U6mvuRBGDFUf4qDUPkxJxRFcaMJHw0OZ7MWBMuM8ZF49C0i6jE94NwPicRsh2HZ6gIAUSDIA2fCz6LCAWju7d6sRBG2vkV3nhHl3wS9YEp2tes1m9TcrryWxaBZmy1FP3AJm7CqI7A6u4xAjiEMCIUisU9n4raWI1Z6+BbUrMgVhk1ccQd6T3vv+U55bE1vbJ7ZrqDZUtIqh0IroPVBVIHeio=";
	public static final String TOKEN_ARQSEND_PRODUCCION = "IdKK0iZ6roxbUiA5na2wTWoSiblx3wRyN1V/QFnVfetfDjkV+0fO4C6HBDaPlLvw+yQaznYHEVP6PbWF7xRnurUsFgqzAGUA4dnz09LO0ilOMOCN61K2N34tFuk6GMZ49BIrJdXWh1egm0RZF7wkOsgZ28Zz5VHkoglFl83I7yYcoecHSuGgRwRS/vucsI0OTuy2kBfekuvGBszSb2tkuW6hDf/ErzmtxpoWVF5UIYWM7IKygzx3wxUK047FkP7n";
	public static final String TOKEN_ARQSEND_DRP = "tqwJAcnkoCG7i8/QXyfrIl0XNFS1RYtQG8iOItxdKL1gSl895vqH3W2nhxK/5KgNnCy60kAb+vnDrObgggdV9n5lO0rqqwgX/UfRl6HWE4IblXEy3eeV9+a4OC0Zc4QPXoV3jk4t/VBguVxn8u847GvVAsrghYz9JAE0QF20fNury5Re83oUvbFVVyXQTLlX46oirkZemHYEY5nEDqwY/HukTSQJl0F5LTWLjDZcPuY=";
	
	/*Variable para envio en grupoNotificacion email*/
	public static final String IV_GRUPONOTIFICACIONES_DESA ="$zu|3m&qVAPakWZ@";
	public static final String IV_GRUPONOTIFICACIONES_PROD ="X]dp@%Ho0@yWpiO4";
	public static final String KEY_GRUPONOTIFICACIONES_EMAIL_DESA ="2fIL2PyT}gNsU]ftHFWoKG8U0tAsiytH";
	public static final String KEY_GRUPONOTIFICACIONES_EMAIL_PROD ="jZgE=zDpj2Q6bVxwXZNdUWnu1uB@YI5J";
	public static final String TOKEN_GRUPONOTIFICACIONES_EMAIL_DESA = "aj4g9t_t=8jFCWmdmEldrwMqfhmavjUAM9sJvcKrqIbrJzpY1nqgCM=";
	public static final String TOKEN_GRUPONOTIFICACIONES_EMAIL_PROD = "etd4ir5tv7sm1FWiIJKphMloPcDGisU8bPEs8BWq484IrssqCdFv9I=";
	/*Variable para envio Notificacion email para firma unica*/
	public static final String TOKEN_GRUPONOTIFICACIONES_EMAIL_CYEE_DESA = "kerebf7omips8o9etYeTc7TacL3t8K7/YpGLhUj6pGKkO9t33XbgQY=";
	public static final String TOKEN_GRUPONOTIFICACIONES_EMAIL_CYEE_PROD = "gmc5wn5lfgwAOyX6WwRbEq5v40fnvNVgrpHaBqtBMdhAOXX95aVKvs=";
	
	/*Variable para envio Notificacion email para actualizacion de datos*/
	public static final String TOKEN_NOTIFICACIONES_ACT_DATOS_EMAIL_DESA = "i5r4oineew=NFNYKG9KVAgQ8qnC6OLB9jks24zWaUwaTbTcuXz10JY=";
	public static final String TOKEN_NOTIFICACIONES_ACT_DATOS_EMAIL_PROD = "SIN TOKEN";
	
	public static final String SMS_HOST = "www.calixtaondemand.com";
	public static final int SMS_PORT = 80;
	public static final String SMS_CLIENTE = "44690";
	public static final String SMS_PASSWORD = "2316459e9a3e498dad3e9c5aa381482ca788176a0426e51625819c0453f53efe";
	public static final String SMS_USER = "smartineza@elektra.com.mx";
	public static final String SMS_PROTOCOLO = "http";
	public static final String SMS_IP_PROXY = "10.50.8.20";
	public static final int SMS_PUERTO_PROXY = 8080;

	/* Variables para la Ruta de las Tasas en la Categoria 58 */
	public static final String RUTA_CATEGORIA_TASA_TELEFONIA = "TELEFONIA PREPAGO";
	public static final String RUTA_CATEGORIA_TASA_ITALIKA = "MOTOS";
	public static final String RUTA_CATEGORIA_TASA_CONSUMO = "CATALOGO";

	// Mensaje cuando no se tiene detalle del error
	public static final String SIN_DETALLE_DE_ERROR = "No se cuenta con detalle del error";

	// Estatus de tarjetas
	// TODO aqui ando
	public static final String ESTATUS_TARJETA_CODIGO_0 = "TRANS JDC";
	public static final String ESTATUS_TARJETA_CODIGO_1 = "PEND. CIERRE";
	public static final String ESTATUS_TARJETA_CODIGO_2 = "PEND. ESTAMPAR";
	public static final String ESTATUS_TARJETA_CODIGO_3 = "ESTAMPANDO";
	public static final String ESTATUS_TARJETA_CODIGO_4 = "ESTAMPADA";
	public static final String ESTATUS_TARJETA_CODIGO_5 = "PEND. ENTREGAR";
	public static final String ESTATUS_TARJETA_CODIGO_6 = "VIGENTE";
	public static final String ESTATUS_TARJETA_CODIGO_7 = "INCIDENCIA";
	public static final String ESTATUS_TARJETA_CODIGO_8 = "FALTANTE";
	public static final String ESTATUS_TARJETA_CODIGO_9 = "ENT SIN ACT";
	public static final String ESTATUS_TARJETA_CODIGO_10 = "PET. BCO.";
	public static final String ESTATUS_TARJETA_CODIGO_11 = "ROBADA";

	// ACTIVACION FLUJO UNICO TIPO DE USUARIOS
	public static final int ID_CAPTACION = 1;
	public static final int ID_SOLICITUD = 2;

	public static final int ID_INSERTA = 1;
	public static final int ID_ACTUALIZA = 2;

	public static final String CODIGO_OPERACION_ALTA = "A";

	// BackOffice- Rechazo Por Gerente
	public static final int ID_STATUS_DOCUMENTOS_RECHAZADOS = 5;
	public static final String ID_BANDERA_VERIFICACION_DEFAULT = "N";
	public static final String ID_DATO_VERIFICACION_DEFAULT = "3";
	public static final String DETALLE_COMENTARIO_VERIFICACION_DEFAULT = "No existen comentarios";
	public static final int PERIODO_PAGO_MENSUAL_DEFAULT = 30;

	public static final String CONTRATOS_LEYEND_FECHA_CORTE = "Cada 7 dias de cada mes a partir de la disposicion de Credito";
	public static final String CONTRATOS_LEYEND_FECHA_LIMITE = "Cada 7 dias de cada mes a partir de la disposicion de Credito";
	public static final String CONTRATOS_LEYENDA_SEGUROS_AZTECA = "Seguros Azteca, S.A de C.V.";
	public static final String CONTRATOS_LEYENDA_SIN_SEGURO = "Sin Seguro";
	public static final String CONTRATOS_LEYENDA_NO_APLICA = "No aplica";
	public static final String CONTRATOS_LEYENDA_SIN_IVA = " Sin IVA";
	public static final String CONTRATOS_LEYENDA_INCLUYE_IVA = " (Incluye IVA)";
	public static final String CONTRATOS_GLOBALES_CAT_CONSUMO = "105.3";
	public static final String CONTRATOS_GLOBALES_TASA_MORATORIA = "180";
	public static final String CONTRATOS_GLOBALES_TASA_ORDINARIA_CONSUMO_MOSTRAR = "52.00";
	public static final String CONTRATOS_GLOBALES_TASA_ORDINARIA_CONSUMO_MOSTRAR_QyM = "61.7";
	public static final String CONTRATOS_GLOBALES_TASA_ORDINARIA_CONSUMO_CALCULOS = "102.00";
	public static final String CONTRATOS_GLOBALES_TASA_ORDINARIA_CONSUMO_CALCULOS_QyM = "123.4";

	public static final String CONTRATOS_INSOLUTOS_CAT_CONSUMO = "105.3";
	public static final String CONTRATOS_INSOLUTOS_TASA_MORATORIA = "141.68";
	public static final String CONTRATOS_INSOLUTOS_TASA_ORDINARIA_CONSUMO_MOSTRAR = "70.84";
	public static final String CONTRATOS_INSOLUTOS_TASA_ORDINARIA_CONSUMO_CALCULOS = "102.00";

	// Quincenal
	public static final String CONTRATOS_LEYEND_FECHA_CORTE_QUINCENAL = "Cada 15 dias de cada mes a partir de la disposicion de Credito";
	public static final String CONTRATOS_LEYEND_FECHA_LIMITE_QUINCENAL = "Cada 15 dias de cada mes a partir de la disposicion de Credito";

	// Mensual
	public static final String CONTRATOS_LEYEND_FECHA_CORTE_MENSUAL = "Cada 30 dias de cada mes a partir de la disposicion de Credito";
	public static final String CONTRATOS_LEYEND_FECHA_LIMITE_MENSUAL = "Cada 30  dias de cada mes a partir de la disposicion de Credito";

	/**********************************************************
	 ************************ BAZDIGITAL************************
	 **********************************************************/

	// Envio de Mensajes
	public static final String ID_MENSAJE_SOLICITUD_PENDIENTE = "BDMMensajes-000004";
	public static final String ID_MENSAJE_CODIGO_BARRAS = "BDMMensajes-000018";
	public static final String ID_MENSAJE_CITA = "BDMMensajes-000019";

	// Consulta de campa�as por Pais, Canal, Sucursal
	public static final String PAQ_CONSULTA_CAMPANIAS = "GSCRSOLPA0151";
	public static final String SP_CONSULTA_CAMPANIAS = "GSCRSOLSPM0004";

	public static final String CTR_CAMPANIAS = "/campania";
	public static final String CTR_CONSULTA_CAMPANIAS = "/consulta";

	// Obtener solicitud reprocesar contratos
	public static final String PAQ_GENERAR_CONTRATOS = "GSCRSOLPA0147";
	public static final String SP_GENERAR_CONTRATOS = "GSCRSOLSPC0001";

	// Alta Dinamica promociones Buen Fin 2017
	public static final String PAQ_BUEN_FIN = "GSCRSOLPA0198";
	public static final String SP_ALTA_PROMOCION = "GSCRSOLSPM0001";
	public static final String SP_VALIDAR_PREMIO_PROMOCION = "GSCRSOLSPM0002";
	public static final String SP_CONFIRMAR_PREMIO_PROMOCION = "GSCRSOLSPM0003";

	// Baz Digital MultiCotizacion
	public static final String PAQ_ALTA_MULTI_COTIZACION = "GSCRSOLPA0244";
	public static final String SP_ALTA_MULTI_COTIZACION = "SP_INSCRE";
	public static final String PAQ_CONSULTA_MULTI_COTIZACION = "GSCRSOLPA0245";
	public static final String SP_CONSULTA_MULTI_COTIZACION = "SP_CONSULTA";
	public static final String CTR_MULTI_COTIZACION  = "/ctrConsultaCampanasXSol";
	public static final String MTD_MULTI_COTIZACION ="/mtdConsultaCampanasXSol";
	
	// Obtener datos solicitudes generico
	public static final String PAQ_CONSULTA_SOL_GENERICO = "GSCRSOLPA0195";
	public static final String SP_CONSULTA_SOL_GENERICO = "GSCRSOLSPM0002";

	/**********************************************************
	 *********************** MESA CONTROL***********************
	 **********************************************************/

	public static final String PAQ_JVC_MCO = "GSCRSOLPA0155";
	public static final String SP_CONSULTA_JVC_PARAMETRIZADO = "GSCRSOLSPM0001";
	public static final String SP_CONSULTA_ULTIMA_RENDICION = "GSCRSOLSPM0003";
	public static final String SP_CONSULTA_REGION_PARAMETRIZADA = "GSCRSOLSPM0004";
	public static final String SP_CONSULTA_MARCAS_SOLICITUD = "GSCRSOLSPM0006";

	// Anterior
	public static final String PAQ_EDICION_DATOS = "GSCRSOLPA0154";
	public static final String SP_BITACORA_EDICION_DATOS = "GSCRSOLSPM0001";

	// Reciente
	public static final String PAQ_BITACORA_SOL = "GSCRSOLPA0159";
	public static final String SP_BITACORA_DATOS_SOLICITUD = "GSCRSOLSPM0001";

	public static final String PAQ_PROCESOS_BATCH = "GSCRSOLPA0158";
	public static final String SP_PENDIENTES_POR_COTIZAR = "GSCRSOLSPM0001";
	public static final String SP_PENDIENTES_POR_LIBERAR = "GSCRSOLSPM0002";
	public static final String SP_PENDIENTES_POR_SURTIR = "GSCRSOLSPM0003";

	public static final String PAQ_FUNCION_CTRM = "GSCRSOLPA0164";
	public static final String FN_CTRM_PENDIENTES_POR_SURTIR = "GSCRSOLSPM0003";

	public static final String PAQ_BITACORAS_MONITOREO_MCO = "GSCRSOLPA0163";
	public static final String SP_BIT_MONITOREO_RENDICION = "GSCRSOLPAM0001";
	public static final String SP_BIT_MONITOREO_REND_NOC_A_MCO = "GSCRSOLPAM0002";
	public static final String SP_BIT_MONITOREO_NOC_A_MCO_INT = "GSCRSOLPAM0003";
	public static final String SP_BIT_MONITOREO_NOC_A_MCO_BATCH = "GSCRSOLPAM0004";

	public static final String PAQ_BITACORAS_MONITOREO_MCO_DICTAMINACIONES = "GSCRSOLPA0196";
	public static final String SP_BIT_MONITOREO_MCO_DICTA_BATCH_INSERTA_Y_ACTUALIZA = "GSCRSOLSPM0001";
	public static final String SP_BIT_MONITOREO_MCO_DICTA_BATCH_CONSULTA = "GSCRSOLSPM0002";

	public static final String PAQ_DINAMICO = "GSCRSOLPKG0004";
	public static final String SP_ALTA_DINAMICA_PART1 = "GSCRSOLSPU0003";
	public static final String SP_ALTA_DINAMICA_PART2 = "GSCRSOLSPC0005";

	public static final String[] IP_NODOS_POOL2 = new String[] { "10.53.37.68",
			"10.53.37.69", "10.53.37.70", "10.53.37.71", "10.53.37.38",
			"10.82.32.83", "10.82.32.84", "10.82.32.85", "10.82.32.86" };

	// Consultar Funcionalidad de Sucursal
	public static final String PAQ_FUNCIONALIDAD_SUC = "GSCRSOLPA0169";
	public static final String SP_FUNCIONALIDAD_SUC = "GSCRSOLSPM0002";
	public static final String SP_FUNCIONALIDAD_SUC_TEMP = "GSCRSOLSPM0003";
	public static final String CTR_SUCURSAL = "/sucursal";
	public static final String CTR_CONSULTA_FUNCIONALIDAD = "/consultaFuncionalidad";
	public static final String CTR_FUNCIONALIDAD_CONSULTAR = "/funcionalidadConsultar";
	public static final String CTR_FUNCIONALIDAD_RECARGAR = "/funcionalidadRecargar";
	public static final String CTR_FUNCIONALIDAD_LISTA_RECARGAR = "/funcionalidadListaRecargar";
	public static final String CTR_FUNCIONALIDAD_LISTA_LIMPIAR = "/funcionalidadListaLimpiar";
	public static final String CTR_FUNCIONALIDAD_RECARGAR_GENERAL = "/funcionalidadRecargarGeneral";
	public static final String CTR_FUNCIONALIDAD_LISTA_LIMPIAR_GENERAL = "/funcionalidadListaLimpiarGeneral";
	public static final String CTR_FUNCIONALIDAD_ESTABLECER_NODO = "/funcionalidadEstablecerNodo";
	public static final String CTR_FUNCIONALIDAD_ESTABLECER_NODO_GENERAL = "/funcionalidadEstablecerNodoGeneral";
	public static final String CTR_FUNCIONALIDAD_MOSTRAR_LISTA_NODOS = "/funcionalidadMostrarListaNodos";
	public static final String CTR_FUNCIONALIDAD_MOSTRAR_LISTA_NODOS_GENERAL = "/funcionalidadMostrarListaNodosGeneral";
	public static final int SUCURSAL_FUNCIONALIDAD_CONFIGURADOR_OC = 1;
	public static final int SUCURSAL_FUNCIONALIDAD_BD = 2;
	public static final int FUNCIONALIDAD_SUCURSAL_TIME_OUT = 999;
	public static final int FUNCIONALIDAD_GENERICA_TIME_OUT = 999;

	// Consulta Funcionalidad de Region
	public static final String PAQ_FUNCIONALIDAD_REGION = "GSCRSOLPA0197";
	public static final String SP_FUNCIONALIDAD_REGION = "GSCRSOLSPM0001";

	// Reglas Genericas NOC
	public static final String CTR_REGLAS_NOC = "/ReglasGenericas";
	public static final String MTD_CONSULTA_REGLAS = "/consultaReglasNOC";

	// Consultar pais y canal de sucursal
	public static final String PAQ_CONSULTA_PAIS_CANAL = "GSCRSOLPA0172";
	public static final String SP_CONSULTA_PAIS_CANAL = "GSCRSOLSPC0003";

	// SP para consultar las colonias mediante el CP.
	public static final String PAQ_CONSULTA_CP = "GSCRSOLPA0177";
	public static final String SP_CONSULTA_COLONIAS = "GSCRSOLSPM0004";

	// SP para obtener las solicitudes para mandar a Mesa - Validacion
	// Automatica
	public static final String PAQ_CONSULTA_SOLICITUDES_PARA_VALIDACION_AUTOMATICA = "GSCRSOLPA0199";
	public static final String SP_CONSULTA_SOLICITUDES_PARA_VALIDACION_AUTOMATICA = "GSCRSOLPAM0001";
	// sp - Validacion Automatica - EXCLUYE MARCAS
	public static final String PAQ_CONSULTA_SOLICITUDES_PARA_VALIDACION_AUTOMATICA_NUEVO = "GSCRSOLPA0204";
	public static final String SP_CONSULTA_SOLICITUDES_PARA_VALIDACION_AUTOMATICA_NUEVO = "GSCRSOLPAM0001";
	public static final String XML_NULL = "1";

	// CONSULTA DE TABLA RENDICION NUEVA
	public static final String PAQ_CONSULTA_SOLICITUDES_RENDICION = "GSCRSOLPA0207";
	public static final String SP_CONSULTA_SOLICITUDES_RENDICION = "GSCRSOLSPM0002";

	// Dias para solicitudes desde rechazadas, solo por defecto
	public static final int DIAS_DESDE_RECHAZO = 60;
	public static final int DIAS_DESDE_RECHAZO_JVC = 0;
	public static final int DIAS_DESDE_RECHAZO_JVC_SIN_EDICION = 7;

	// SP - REQ: DIASRECHAZOJV60DIAS
	public static final String PQ_DIASRECHAZOJV60DIAS = "GSCRSOLPA0232";
	public static final String SP_DIASRECHAZOJV60DIAS = "GSCRSOLSPM0001";

	public static final String PQ_SOLICITUDESRECHAZADASCU = "GSCRSOLPA0249";
	public static final String SP_SOLICITUDESRECHAZADASCU = "GSCRSOLSPM0001";

	// CREDITO INMEDIATO INHABILITADO
	public static final int CRED_INMEDIATO_INHABILITADO_POR_EDICION_DATOS = 0;

	// Dispositivos Moviles
	public static final String CTR_DISPOSITIVOS_MOVILES = "/dispositivosMoviles";
	public static final String MTD_GUARDAR_ENCUESTA_EXPEDIENTE = "/guardarEncuestaExpediente";
	public static final String MTD_CONSULTA_BURO = "/consultaBuro";
	public static final String MTD_VALIDAR_EXISTENCIA_SOLITITUD = "/validarExitenciaSolicitud";
	public static final String MTD_VALIDAR_CREDITO_INMEDIATO = "/validarCreditoInmediato";
	public static final String MTD_VALIDAR_DUPLICIDAD_RENDICION = "/validaDuplicidadDeRendicion";
	public static final String CTR_PROCESO_UNIFICADO_JV = "/procesoUnificadoJV";
	public static final String CTR_EDITAR_DATOS = "/edicionDeDatos";
	public static final String CTR_GUARDAR_ENCUESTA = "/guardarEncuestaInvestigacion";

	/***************************************************************
	 ******************** MESA DE CONTROL - BURO*********************
	 **************************************************************/
	public static final String PAQ_ACTUALIZA_BATERIA = "GSCRSOLPA0185";
	public static final String SP_ACTUALIZA_BATERIA = "GSCRSOLSPI0001";

	public static final String PAQ_CONSULTA_BATERIA = "GSCRSOLPA0185";
	public static final String SP_CONSULTA_BATERIA = "GSCRSOLSPC0002";

	// Menor edad para investigar, si es menor a MENOR_EDAD tratar como AMARILLO
	// o NARANJA
	public static final int MENOR_EDAD = 22;
	public static final int PARAMETRO_ENGANCHE_ITALIKA_MENORES_EDAD = 2;
	// Monto maximo permitido en montos y plazos
	public static final float MONTO_MAXIMO_ORIGINACION = 12000;
	public static final float MONTO_MAXIMO_RECOMPRA_BAZ_DIGITAL = 70000;
	public static final float MONTO_MAXIMO_ITALIKA_BAZ_DIGITAL = 99000;
	public static final float MONTO_MAXIMO_PREAPROBADO_SIPA = 50000;
	public static final float MONTO_MAXIMO_PREAPROBADO_CAPTA = 40000;

	// Consulta catalogo de funcionalida Generica
	public static final String PAQ_FUNCIONALIDA_GENERECIA_NOC = "GSCRSOLPA0183";
	public static final String FUNCION_CONSULTA_CATALOGO_PARAMETRIZADO = "GSCRSOLFNC0002";
	public static final String FUNCION_CONSULTA_CATALOGO_PARAMETRIZADO01 = "GSCRSOLFNC0001";

	public static final String PAQ_EDICION_DATOS_GENERICO = "GSCRSOLPA0179";
	public static final String SP_REGISTRA_EDICION_DATOS = "GSCRSOLSPM0004";
	public static final String SP_CONSULTA_BITACORA_EDICION_DATOS = "GSCRSOLSPM0005";
	public static final String SP_CONSULTA_BITACORA_EDICION_DATOS_POR_JV = "GSCRSOLSPM0006";

	public static final String PAQ_EDICION_DATOS_GENERICO_ACTUALIZADO = "GSCRSOLPA0205";
	public static final String SP_CONSULTA_BITACORA_EDICION_DATOS_POR_JV_ACTUALIZADO = "GSCRSOLSPM0001";
	
	//Obtener solicitudes de respaldo sin edicion de datos.
	
	public static final String PAQ_SOLICITUDES_RESPALDO_SIN_EDICION_DATOS = "GSCRSOLPA000207";
	public static final String SP_SOLICITUDES_RESPALDO_SIN_EDICION_DATOS= "GSCRSOLSPM00002";

	// Longitud maxima para nombres,apellidoPaterno, apellidoMaterno (CU)
	public static final int LONGITUD_DATOS_NOMBRES = 50;
	// Longitud maxima para calle,colonia,poblacion, estado (CU)
	public static final int LONGITUD_DATOS_DOMICILIO = 65;
	// rango max de secciones de solicitudes en Quartz
	public static final int RANGO_MAX_SECCIONAR_SOL = 200;
	// VALIDAR FIRMAS CONTRATOS DIGITALIZADOS
	public static final String CTR_VALIDAR_FIRMAS_CONTRATOS = "/validarFirmasContratos";
	public static final String MTD_VALIDA_FIRMAS = "/validaFirmas";

	// Versiones contratos
	public static final String PAQ_VERSIONES_CONTRATOS = "GSCRSOLPA0194";
	public static final String SP_CONSULTA_VERSIONES_CONTRATOS = "GSCRSOLSPM0002";
	public static final String SP_ALTA_VERSIONES_CONTRATOS = "GSCRSOLSPM0004";

	// Servicios Puente
	public static final String CTR_SERVICIOS_PUENTE_PREFORMALIZAR_ALNOVA = "/ServiciosPuente/preformalizarAlnova";
	public static final String CTR_SERVICIOS_PUENTE_AUTORIZADOR_TOTALPLAY = "/ServiciosPuente/autorizadorTotalPlay";
	public static final String CTR_SERVICIOS_PUENTE_CONSULTACDP_TOTALPLAY = "/ServiciosPuente/consultaCapacidadPagoTP";
	public static final String CTR_SERVICIOS_PUENTE_ALTACU_TOTALPLAY = "/ServiciosPuente/altaClienteUnicoTP";

	// Consulta cliente preaprobado SIPA por nombre
	public static final String CONSULTA_CLIENTEXNOMBRE = "/clienteunico/consulta/clientexnombre";

	// Paga recomienda y gana
	public static final String CONSULTA_CUENTAS_GUARDADITO = "/consulta/cuentas/guardadito";
	public static final String VALIDA_CLIENTE_RECOMENDADOR = "/valida/cliente/recomendador";
	public static final String GENERA_FOLIO_RECOMENDADOR = "/genera/folio/recomendador";

	// Actualizar CDP nuevos productos MOC
	public static final String ACTUALIZAR_CDP_NUEVOS_PRODUCTOS_MOC = "/BuroDeCredito/nuevosProductosMOC/ActualizarCDP";
	
	// Actualizar CDP campa�as MOC
	public static final String ACTUALIZAR_CDP_CAMPANA_MOC = "/BuroDeCredito/campanas/ActualizarCDPCampana";

	// PAQUETE PAGA PROCEDIMIENTOS ALMACENADOS PAGA RECOMIENDA Y GANA *jade*
	public static final String PAQUETE_PAGA_RECOMIENDA_GANA = "GSCRSOLPA0236";
	public static final String PAQ_PAGA_RECOMIENDA_GANA = "GSCRSOLPA0240";
	public static final String SP_GUARDAR_RECOMENDADOR = "GSCRSOLSPM0001";
	public static final String SP_GUARDAR__RELACION_RECOMENDADOR = "GSCRSOLSPM0002";
	public static final String SP_CONSULTAR__FOLIO_RECOMENDADOR = "GSCRSOLSPM0003";
	public static final String SP_CONSULTAR_RECOMENDADOR_POR_FOLIO = "GSCRSOLSPS0001";
	public static final String PLANTILLA_SMS_PRG = "plantilla PRG";
	
	// PAQUETE PARA PROCEDIMIENTOS ALMACENADOS OS
	public static final String PAQ_CONSULTAR_MARCAS_OS = "GSCRSOLPA2063";
	public static final String SP_CONSULTAR_MARCAS_OS = "GSCRSOLSPM0004";

	// Consultar estatus de tarjeta MP48 ING 223048
	public static final String MTD_CONSULTA_STATUS_TARJETA = "/mtdconsultastatustarjeta";

	// Busca referencias por idSolicitud
	public static final String MTD_BUSCA_REFERENCIAS_PORIDSOLICITUD = "/buscarReferencia";
	public static final String CTR_BUSCA_REFERENCIAS_PORIDSOLICITUD = "/referencias";
	
	//servicios puente TOTAL PLAY
	//base de datos para total play
	public static final String IP_SUCURSAL_VIRTUAL_TP_DESARROLLO = "10.54.28.233";
	public static final String IP_SUCURSAL_VIRTUAL_TP_PRODUCCION = "10.53.50.107";
	public static final String PAIS_SUCURSAL_VIRTUAL_TP = "1";
	public static final String CANAL_SUCURSAL_VIRTUAL_TP = "1";
	public static final String NUMERO_SUCURSAL_VIRTUAL_TP_DESARROLLO = "673";
	public static final String NUMERO_SUCURSAL_VIRTUAL_TP_PRODUCCION = "9965";
	public static final String USUARIO_CLIENTE_UNICO_TP = "USRTPY";
	
	public static final String PAQUETE_TOTAL_PLAY = "GSCRSOLPA0246";
	public static final String SP_TOTALPLAY_ALTA = "GSCRSOLSPM0001";
	public static final String SP_TOTALPLAY_CONSULTA = "GSCRSOLSPC0002";
	
	// Parametros de BD (consulta, reset o eliminar y update)
	public static final String CTR_CONSULTA_PARAMETROS_DB = "/parametrosBD";
	public static final String MTD_CONSULTA_PARAMETROS_DB = "/consultaParametros";

	// BazDigital - GuardarTipoFlujo
	public static final String PAQ_GUARDAR_TIPO_FLUJO = "GSCRSOLPA0267";
	public static final String SP_GUARDAR_TIPO_FLUJO = "GSCRSOLSPM0005";
	public static final String SP_INSERTAR_CATALOGO_TIPO_FLUJO = "GSCRSOLSPM0001";
	public static final String SP_CONSULTAR_TIPO_FLUJO = "GSCRSOLSPM0007";
	
	//Guardar presupuesto en BD NOC
	public static final String PAQ_GUARDAR_PRESUPUESTO = "GSCRSOLPA0298";
	public static final String SP_GUARDAR_PRESUPUESTO = "GSCRSOLSPI0001";
	public static final String CTR_PRESUPUESTO ="/presupuesto";
	public static final String MTD_GUARDAR_PRESUPUESTO ="/guardarPresupuesto";
	
	//Guardar Datos Cambaceo
		public static final String PAQ_ACTUALIZAR_DATOS_CAMBACEO = "GSCRSOLPA0291";
		public static final String SP_ACTUALIZAR_DATOS_CAMBACEO = "GSCRSOLSPM0003";
		public static final String CTR_CAMBACEO ="/datosCambaceo";
		public static final String MTD_GUARDAR_DATOS_CAMBACEO ="/actualizar";
		
	//PARA CONSULTAR LIMITES DE CREDITO
	public static final String PAQ_LIMITES_DE_CREDITO = "GSCRSOLPA0301";
	public static final String SP_CONSULTA_LIMITES_DE_CREDITO = "GSCRSOLSPC0001";
	public static final String CTR_LIMITES_DE_CREDITO  = "/ctrConsultaLimitesDeCredito";
	public static final String MTD_LIMITES_DE_CREDITO ="/mtdConsultaLimitesDeCredito";

	public static final String CONSULTA_MARCAS_OS = "/solicitud/consulta/marcasos";
	// Cierre de puertas
	public static final String CTR_CIERRE_PUERTAS = "/cierrePuertas";
	public static final String MTD_CONSULTA_CIERRE_PUERTAS = "/consultar";

	//Nuevo flujo liberacion
	public static final String MTD_GUARDAR_DIA_PAGO_NVO_FLUJO_LIBERACION = "/guardarDiaPagoNvoFlujoLib";
	
	//PARA LA BITACORA DE TIEMPOS
	public static final String CTR_BITACORA_DE_TIEMPOS  = "/ctrBitacoraDeTiempos";
	public static final String MTD_BITACORA_DE_TIEMPOS 	= "/mtdBitacoraDeTiempos";
	
	//Consultar por id credito
	public static final String PAQ_CONSULTAR_ID_CREDITO="GSCRSOLPA0003";
	public static final String SP_CONSULTAR_ID_CREDITO="GSCRSOLSPM0001";
	
	//Paquete de SP consulta de guardado de datos
	public static final String PAQ_GUARDAR_DETALLE_COTIZACION = "GSCRSOLPA0306";
	public static final String SP_GUARDAR_DETALLE_COTIZACION  = "GSCRSOLSPM0001";
	
	//Paquete de SP consulta de recuperacion de datos
	public static final String PAQ_CONSULTA_DETALLE_COTIZACION= "GSCRSOLPA0306";
	public static final String SP_DETALLE_COTIZACION = "GSCRSOLSPC0003";
	
	//controller y mtd para consumo
	public static final String MTD_GUARDAR_DETALLE_COTIZACION ="/mtdguardarDetalleCotizacion";
	public static final String CTR_DETALLE_COTIZACION ="/ctrDetalleCotizacion";
	public static final String MTD_RECUPERACION_DETALLE_COTIZACION="mtdConsultarDetalleCotizacion";
	
	//Flujo garantias
	public static final String PAQ_GARANTIAS_SOLICITUD="GSCRSOLPA0316";
	public static final String SP_CONSULTA_GARANTIAS_SOL="GSCRSOLSPM0003";
	
	public static final String CTR_SOLICITUDES_NOC="/ctrSolicitudNoc";
	public static final String MTD_CONSULTA_SOLICITUDES="mtdConsultaSolicitudes";
	public static final String MTD_CONSULTA_SOLICITUDES_DOS="mtdConsultaSolicitudesDos";
	
	public static final String CTR_SOLICITUDES_FENIX_COMERCIO="/ctrSolicitudesFenixComercio";
	public static final String MTD_CONSULTA_SOLICITUDES_FENIX_COM="mtdConsultaSolicitudesFenixCom";
	public static final String MTD_CONSULTA_SOLICITUDES_FENIX_COMERCIO="mtdConsultaSolicitudesFenixComercio";
	
	public static final String CONSULTA_SOLICITUDES_RESPALDO_EDICION_DATOS="/consultaSolicitud/SinEdicionDatos";
	//flujo tasas
	public static final String MTD_CONSULTAR_ABONOS = "/consultarAbonos";
	public static final String MTD_CONSULTAR_TASA_ESPECIFICA = "/consultarTasaEspecifica";
	
	//flujo Funnel de solicitudes
	public static final String PAQ_FUNNEL_SOLICITUDES="GSCRSOLPA000335";
	public static final String SP_ALTA_FUNNEL_SOL="SPPRINCIPALX";
	public static final String SP_CONSULTA_FUNNEL_SOL="SPCONSULTA";
	
	public static final String MTD_ALTA_FUNNEL_SOL = "/altaDatosFunnel";
	public static final String MTD_CONSULTA_FUNNEL_SOL = "/consultaDatosFunnel";
	
	//flujo validar numero telefono existente
	public static final String MTD_VALIDAR_NUM_TEL = "/validarNumTel";

	//consumir sp para generar credito empleados
	public static final String CTR_GENERA_CRED_EMP = "/ctrCreditoEMP";
	public static final String MTD_GENERA_CRED_EMP = "/generaCreditoEmp";
	
	// Actualiza el d�a de pago y actualiza la periodicidad cuando es un rescate.
	public static final String MTD_DIAPAGO_PERIODICIDAD = "/actualizaRescate";
	public static final String CTR_ACTUALIZA_DIAPAGO_PERIODICIDAD = "/periodicidadDiaPago";

	//SP - Consulta Datos OS No Presencial	
	public static final String PAQ_ALTA_OS_NO_PRESENCIAL = "GSCRSOLPA0314";
	public static final String SP_ALTA_OS_NO_PRESENCIAL = "GSCRSOLSPM0001";
	public static final String SP_CONSULTA_OS_NO_PRESENCIAL = "GSCRSOLSPM0002";
	public static final String SP_ACTUALIZA_OS_NO_PRESENCIAL = "GSCRSOLSPM0003";
	
	public static final String CTR_SOLICITUDES_FENIX_BANCO="/ctrSolicitudesFenixBanco";
	public static final String MTD_CONSULTA_SOLICITUDES_FENIX_BNK="mtdConsultaSolicitudesFenixBnk";
	public static final String MTD_CONSULTA_SOLICITUDES_FENIX_BANCO="mtdConsultaSolicitudesFenixBanco";
	
	//actualizacionDatos
	public static final String MTD_ACTUALIZACION_DATOS = "/actualizacionDatos";
	public static final String CTR_INVESTIGACION= "/controlInvestigacion";
	public static final String CTR_RESPALDA_DATOS = "/respaldaDatos";
	public static final String CTR_ACTUALIZAR_DATOS = "/actualizarDatos";
	public static final String MTD_REPLICAR_DATOS = "/procesoReplicaDatos";
	public static final String CTR_REPLICAR_DATOS = "/replicarDatos";
	public static final String MTD_ACTDATOS_OBTENER_SOLICITUDES = "/ctrActDatosObtenerDatos";
	public static final String CTR_ACTDATOS_SOLICITUDES_ASESOR = "/mtdActDatosSolicitudesAsesor";
	public static final String CTR_ACTDATOS_SOLICITUDES_POR_NOMBRE = "/actDatosSolocitudesPorNombre";
	public static final String CTR_ACTDATOS_RECUPERAR_SOLICITUD = "/actDatosRecuperarSolicitud";
	
	//Consultas Cursor
	public static final String SP_CONSULTA_CURSOR = "/consultar";
	
	//Actualizar Datos Cursor
	public static final String SP_INSERTA_CURSOR = "/actualizar";
	
	//Actualizacion Datos
	public static final String MTD_BUSQUEDA_HOMONIMOS_ACT_DATOS = "/busquedaHomonimosActDatos";
	public static final String PAQ_CONSULTA_SOLICITUD_TIPO213CU="GSCRSOLPA000210";
	public static final String SP_CONSULTA_SOLICITUD_TIPO213CU="gscrsolspc00004";
	
	//consultar configuracion orquestador
	public static final String CONSULTA_CONFIGURACION_SOLICITUD_ORQUESTADOR = "consulta/configuracionSolicitud";
	public static final String CONSULTA_CONFIGURACION_SOLICITUD_HEADER_IP_DESARROLLO = "10.51.83.115";
	public static final String CONSULTA_CONFIGURACION_SOLICITUD_HEADER_IP_PARCIAL = "10.53.37.37";
	public static final String CONSULTA_CONFIGURACION_SOLICITUD_HEADER_IP_PRODUCCION = "10.53.37.37";
	public static final String CONSULTA_CONFIGURACION_SOLICITUD_HEADER_USER = "MSOMOC";
	public static final String CONSULTA_CONFIGURACION_SOLICITUD_HEADER_PASS = "U2VndXJpZGFkTU9DTVNPNjk5Ni4=";

	//Lada para numero celular de mexico
	public static final String LADA_CELULAR_MEX =  "521"; 
	
	public static final String CTR_CTE_GUARDADITO = "/ctrConsulta";
	public static final String MTD_CTE_GUARDADITO = "/mtdCteGuardadito";
	public static final String MTD_CTE_GUARDADITO_MOC = "/mtdCteGuardaditoMOC";
	
	//Para la APPI de las Estrellas
	public static final String MTD_APIGEE = "/ApiGee"; 
	public static final String CTR_API_ESTRELLAS_GET_BANDERA = "/GetBandera"; 
	public static final String CTR_API_ESTRELLAS_ENVIA_CALIFICACION = "/SendScore"; 
	public static final String USUARIO_TOKEN_API_ESTRELLAS_DESARROLLO = "p7uC1O4ZECVdajRcos3plYb7Jg0E3ECl"; 
	public static final String PASS_TOKEN_API_ESTRELLAS_DESARROLLO = "Fj0k5YRDsaguobYE"; 
	public static final String USUARIO_TOKEN_API_ESTRELLAS_PRODUCCION = "67XsiwqupmRIJMRGAPJWds0bP6hNYJ0C"; 
	public static final String PASS_TOKEN_API_ESTRELLAS_PRODUCCION = "PwVDstxQICwyXRPA"; 
	
	//C�digo de respuesta exitosa del orquestador
	public static final String CODIGO_EXITOSO_ORQUESTADOR = "100200";
	
	//Inserta datos migracion solicitudes
	public static final String PAQ_ALTA_DATOS_MIGRACION = "GSCRSOLPA000378";
	public static final String SP_ALTA_DATOS_MIGRACION = "GSCRSOLSPC0001";
	
	//Validar huellas cliente
	public static final String MTD_VALIDAR_HUELLAS_CLIENTE_V2 = "/validarHuellasClienteV2";
	
	//BITACORA baja de coacreditado/solidario
	public static final String BITACORA_BAJA_COACREDITADO = "/bitacoraBajaCoacreditado";
	public static final String CONSULTA_BITACORA_BAJA_COACREDITADO = "/consultaBitacoraBajaCoacreditado";
	public static final String INSERTA_BITACORA_BAJA_COACREDITADO = "/insertaBitacoraBajaCoacreditado";
	
	//DESLIGUE DE SOLICITUDES COACREDITADO
	public static final String DESLIGUE_MOC = "/desligueSolicitudes";
	public static final String DESLIGUE_CLIENTE_Y_OS = "/clienteYObligadoSolidario";
}