/*
 *Leer dos archivos y los compara linea a linea
 *si no son iguales muestra cuales lineas son distintas
 *la comparacion es parametrizada(1-convertir a mayuscula todo,2-dejar como esten) 
 */
package logs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class Compara_Archivos {

	public static void main(String[] args) {
		// Primer archivo a leer
		File fichero1 = new File("/home/ichidaime/Documentos/LogsATM/100logs/base.txt");
		// Segundo archivo a leer
		File fichero2 = new File("/home/ichidaime/Documentos/LogsATM/100logs/O00178_SalidaDSI.txt");
		// llamado ala funcion que compara los archivos
		LeerFichero(fichero1, fichero2);
	}

	public static void LeerFichero(File Ffichero1, File Ffichero2) {
		try {
			String NumLineaDist = "";
			List<String> listaFile1 = new ArrayList<String>();
			List<String> listaFile2 = new ArrayList<String>();
			List<ServicesDTO> servicesDTOList = new ArrayList<ServicesDTO>();
			/* Si existe el fichero */
			if (Ffichero1.exists() && Ffichero2.exists()) {
				/* Abre un flujo de lectura a el fichero1 */
				BufferedReader archivoBaseOriginal = new BufferedReader(new FileReader(Ffichero1));
				/* Abre un flujo de lectura a el fichero2 */
				BufferedReader archivoLogs = new BufferedReader(new FileReader(Ffichero2));
				String lineaFileBase = "", lineaFileLogs = "";
				ServicesDTO servicesDTO = null;
				System.out.println("**********Comparando Fichero***********");
				int contador1 = 0, contador2 = 0, contador = 0;
				/* Lee el fichero line a linea hasta llegar a la ultima */
				while (lineaFileBase != null || lineaFileLogs != null) {
					servicesDTO = new ServicesDTO();
					lineaFileBase = archivoBaseOriginal.readLine();
					lineaFileLogs = archivoLogs.readLine();

					/* Si alguno de los dos Fichero no se a acabado de leer */
					if (lineaFileBase != null) {
						contador1++;
					}
					if (lineaFileLogs != null) {
						contador2++;
					}
					contador++;
					// si no es la ultima lectura para algun archivo para evitar excepcion por null
					if (lineaFileBase != null && lineaFileLogs != null) {
						// Si no son iguales las lineas
						if (!lineaFileBase.trim().toUpperCase().equals(lineaFileLogs.trim().toUpperCase())) {
							if (lineaFileLogs.contains("SERVICE_NAME")) {
								servicesDTO.setDisplay_name(lineaFileLogs);
								System.out.println("SERVICE_NAME :" + lineaFileLogs);
							} else if (lineaFileLogs.contains("DISPLAY_NAME")) {
								System.out.println("DISPLAY_NAME :" + lineaFileLogs);
								servicesDTO.setDisplay_name(lineaFileLogs);
							} else if (lineaFileLogs.contains("STATE")) {
								System.out.println("STATE :" + lineaFileLogs);
								servicesDTO.setState(lineaFileLogs);
							}

							if (lineaFileLogs.contains("STOPPED") || lineaFileLogs.contains("RUNNING")) {

								if (!(servicesDTO.getService_name().isEmpty())
										&& !(servicesDTO.getDisplay_name().isEmpty()
												&& !(servicesDTO.getState().isEmpty()))) {
									servicesDTOList.add(servicesDTO);
								}

							}
						} else {
							// si no es la ultima entrada al while donde ambos son null
							if (!(lineaFileBase == null && lineaFileLogs == null)) {
								NumLineaDist += "," + contador;
							}
						}

					}
				}
				System.out.println("*********Fin Comparacion Fichero**********");
				System.out.println(Ffichero1.getName() + "Tiene " + contador1 + " Lineas");
				System.out.println(Ffichero2.getName() + "Tiene " + contador2 + " Lineas");
				System.out.println("Las Lineas Distintas son " + NumLineaDist);
				/* Cierra el flujo */

				archivoBaseOriginal.close();
				archivoBaseOriginal.close();
				System.out.println("Tamaño de la lista " + servicesDTOList.size());
				for (ServicesDTO servicesDTO2 : servicesDTOList) {
					System.out.println("*********servicios diferentes al original**********");
					System.out.println("SERVICE_NAME " + servicesDTO2.getService_name());
					System.out.println("DISPLAY_NAME " + servicesDTO2.getDisplay_name());
					System.out.println("STATE " + servicesDTO2.getState());
				}
			} else {
				System.out.println("Alguno De Los Ficheros No Existe");
			}

		} catch (Exception ex) {
			/* Captura un posible error y le imprime en pantalla */
			System.out.println(ex.getMessage());
		}
	}
}