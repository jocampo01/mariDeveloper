package com.bancoazteca.canales.terceros.web.utilerias;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringWriter;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Base64;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.springframework.util.StreamUtils;

import com.fasterxml.jackson.databind.JsonNode;

import java.nio.charset.Charset;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

public class AutenticacionAPITokenTelefonia {

	public String getAuthToken(String clientId, String clientSecret) throws Exception {

		String body = "grant_type=" + URLEncoder.encode("client_credentials", "UTF-8") + "&" + "scope="
				+ URLEncoder.encode("messaging:push", "UTF-8") + "&" + "client_id="
				+ URLEncoder.encode(clientId, "UTF-8") + "&" + "client_secret="
				+ URLEncoder.encode(clientSecret, "UTF-8");

		URL authUrl = new URL("https://dev-api.bancoazteca.com.mx:8080/oauth2/v1/token");
		HttpsURLConnection con = (HttpsURLConnection) authUrl.openConnection();
		con.setDoOutput(true);
		con.setRequestMethod("POST");
		con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		con.setRequestProperty("Charset", "UTF-8");
		OutputStream os = con.getOutputStream();
		os.write(body.getBytes("UTF-8"));
		os.flush();
		con.connect();

		String responseContent = parseResponse(con.getInputStream());
		org.json.JSONObject parsedObject = new org.json.JSONObject(responseContent);
		String accessToken = parsedObject.getString("access_token");
		return accessToken;
	}

	private String parseResponse(InputStream in) throws Exception {
		InputStreamReader inputStream = new InputStreamReader(in, "UTF-8");
		BufferedReader buff = new BufferedReader(inputStream);
		StringBuilder sb = new StringBuilder();
		String line = buff.readLine();
		while (line != null) {
			sb.append(line);
			line = buff.readLine();
		}
		return sb.toString();
	}

}
