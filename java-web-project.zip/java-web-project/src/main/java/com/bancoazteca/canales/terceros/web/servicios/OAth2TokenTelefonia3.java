package com.bancoazteca.canales.terceros.web.servicios;

import java.io.IOException;
import java.util.Arrays;

import org.apache.commons.codec.binary.Base64;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.URL;
import java.util.Base64;

public class OAth2TokenTelefonia3 {

	private static final String clientId = "";// clientId
	private static final String callBackUrl = "";// The url defined in WSO2
	private static final String authorizeUrl = "https://dev-api.bancoazteca.com.mx/oauth2/v1/token";
	String authorizationRedirect = getAuthGrantType(callBackUrl);

	private static String getAuthGrantType(String callbackURL) {
		return authorizeUrl + "?response_type=code&client_id=" + clientId + "&redirect_uri=" + callbackURL
				+ "&scope=openid";
	}

//Wait for user to logIn and then
//getAccessToken(with the authorizationCode from header name 'authorization_code', callbackUrl);
//Then call useBearerToken('access_token')
	private static void useBearerToken(String bearerToken) {
		BufferedReader reader = null;
		try {
			URL url = new URL("https://dev-api.bancoazteca.com.mx/oauth2/v1/token");
			HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
			connection.setRequestProperty("Authorization", "Bearer " + bearerToken);
			connection.setDoOutput(true);
			connection.setRequestMethod("GET");
			reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String line = null;
			StringWriter out = new StringWriter(
					connection.getContentLength() > 0 ? connection.getContentLength() : 2048);
			while ((line = reader.readLine()) != null) {
				out.append(line);
			}
			String response = out.toString();
			System.out.println(response);
		} catch (Exception e) {

		}
	}
}