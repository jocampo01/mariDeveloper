package com.bancoazteca.canales.terceros.web.constantes;

public class ConstantsWS {

	/*
	 * Datos de la versi�n del aplicativo
	 * 
	 * @Versi�n
	 * 
	 * @Carpeta Virtual *
	 */

}