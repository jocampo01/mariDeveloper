package com.bancoazteca.canales.terceros.web.servicios;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Properties;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.oltu.oauth2.client.request.OAuthBearerClientRequest;
import org.apache.oltu.oauth2.common.utils.OAuthUtils;
import org.springframework.security.oauth2.common.util.OAuth2Utils;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.Timeout;


public class ClientPreemptiveBasicAuthentication {

	OkHttpClient client = new OkHttpClient();
	public static final MediaType mediaType = MediaType.parse("application/json; charset=utf-8");
    public String ObtenerTokenAPIGee() throws IOException {
    	String accessToken="";

    	String cid="";
    	String csecret="";
    	
    	URL refreshUrl=new URL("https://dev-api.bancoazteca.com.mx/oauth2/v1/token");
        HttpURLConnection urlConnection = (HttpURLConnection) refreshUrl.openConnection();
        urlConnection.setDoInput(true);
        urlConnection.setRequestMethod("POST");
        urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        urlConnection.setUseCaches(false);
        String urlParameters  = "grant_type=refresh_token&client_id="+cid+"&client_secret="+csecret;

        urlConnection.setDoOutput(true);
        DataOutputStream wr = new DataOutputStream(urlConnection.getOutputStream());
        wr.writeBytes(urlParameters);
        wr.flush();
        wr.close();

        int responseCode = urlConnection.getResponseCode();
    	
        if(responseCode==200){
            BufferedReader in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
        }

    	MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
    	RequestBody body = RequestBody.create(mediaType, "grant_type=client_credentials");
    	Request request = new Request.Builder()
    	  .url("https://dev-api.bancoazteca.com.mx/oauth2/v1/token")
    	  .post(body)
    	  .addHeader("Content-Type", "application/x-www-form-urlencoded")
    	  .addHeader("cache-control", "no-cache")
    	  .addHeader("user_id", "")
          .addHeader("user_password", "")
    	  .build();
    	
    	RequestBody formBody = new FormBody.Builder()
    	        .add("search", "Jurassic Park")
    	        .build();
    	    Request requestParameters = new Request.Builder()
    	        .url("https://dev-api.bancoazteca.com.mx/oauth2/v1/token")
    	        .post(formBody)
    	        .build();
    	 
    	Response response = client.newCall(request).execute();
    	if (response.isSuccessful()) {
    	System.out.println(response.body().string());
    	}
    	return accessToken;
    }
    
    String post(String url, String json) throws IOException {
	    RequestBody body = RequestBody.create(mediaType, json);
	    Request request = new Request.Builder()
	        .url(url)
	        .post(body)
	        .build();
	    try (Response response = client.newCall(request).execute()) {
	      return response.body().string();
	    }
	  }
}